'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"https://bhfw.guet.edu.cn/bgt/"'
}
