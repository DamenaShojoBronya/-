<template>
  <div class="title"><h1>报告厅管理平台</h1></div>
</template>

<style >
.title {
  margin: auto;
  font-size: 30px;
  text-align: center;
  /* color: ; */
}
</style>
