// 实例化APP，获取请求URL
var app = getApp()
var url = app.globalData.url

// 自定义网络请求
// 实现网络请求异步等待，并在回调中处理常用的数据情况（session过期，账密失效，服务器繁忙，未知错误等~）

// 传入URL +  data
// 处理数据，请求，返回相关数据
// 返回-1则代表网络请求回调中已经处理相关事件
// 返回1代表密码错误，已清除缓存
function request(lurl, data = {}, method = "POST") {
  return new Promise(function (resolve, reject) {
    getToken().then(token => {
      var header = {};
      if(token != null){
        header = {token: token}
      }
      wx.request({
        url: url + lurl,
        method: method,
        header: header,
        data: data,
        success(res) {
          if (res.data.status == 20000) {
            resolve(res.data.data)
          } else if (res.data.status == 30002) {
            login()
            wx.showToast({
              title: '登录状态失效，已为您重新登录！',
            })
            wx.navigateBack({
              delta: 1,
            })
          } else {
            wx.showToast({
              title: res.data.message,
              icon: "none"
            })
            resolve(-1)
          }
        },
        fail(res) {
          wx.showToast({
            title: "网络连接失败！",
            icon:"none"
          })
          resolve(-1)
        }
      })
    })
  })
}

function getToken() {
  return new Promise(function (resolve, reject) {
    wx.getStorage({
      key: 'token',
      success(res) {
        if (res != "") {
          resolve(res.data)
        } else {
          resolve(null)
        }
      },
      fail() {
        resolve(null)
      }
    })
  })
}

function login() {
  return new Promise(function (resolve, reject) {
    if (!app.globalData.loginning) {
      app.globalData.loginning = true;
      wx.login({
        success(res) {
          var code = res.code
          this.request("auth/wechat/login", {
            code: code
          }).then(res => {
            if (res != -1) {
              resolve(0)
            }
            resolve(-1)
          })
        },
        fail() {
          wx.showToast({
            title: 'title',
            icon: '微信登录失败！'
          })
        }
      })
    }

  })
}


// 将函数暴露以实现开放接口
module.exports = {
  request: request
}