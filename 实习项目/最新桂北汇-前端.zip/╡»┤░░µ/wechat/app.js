App({
  globalData: {
    // url:'https://bhfw.guet.edu.cn/gbh/',
    // url:'http://127.0.0.1:11141/',

    
    url:'https://gdbh.liuxincode.cn:9034/',
    // url: 'http://192.168.4.213:11141/',
    loginning: false, // 是否再登录状态 
    webViewUrl: 'https://bhfw.guet.edu.cn/gbh/',
  },

  onLaunch: function (options) {
    wx.removeStorageSync('token')
    wx.removeStorageSync('name')
    const updateManager = wx.getUpdateManager()
    updateManager.onCheckForUpdate(function (res) {
      console.log(res.hasUpdate)
    })
    updateManager.onUpdateReady(function () {
      wx.showModal({
        title: '更新提示',
        content: '为了不影响使用，请立即更新小程序！',
        showCancel: false,
        confirmText: '好的',
        success: function (res) {
          if (res.confirm) {
            updateManager.applyUpdate()
          }
        }
      })
    })

    updateManager.onUpdateFailed(function () {
      wx.showModal({
        title: '更新提示',
        content: '新版本下载失败',
        showCancel: false,
      })
    })
    this.login()
  },
  login() {
    var that = this
    wx.login({
      success(res) {
        var code = res.code
        wx.request({
          url: that.globalData.url + "auth/wechat/login",
          method: "POST",
          data: {
            code: code
          },
          success(res) {
            if (res.data.status == 20000) {
              wx.setStorageSync('token', res.data.data.token)
              wx.setStorageSync('userInfo', res.data.data.userInfo)
              wx.setStorageSync('type', res.data.data.type)
            } else {
              wx.showToast({
                title: res.data.message,
                icon: "none"
              })
              wx.removeStorageSync('token')
              wx.removeStorageSync('userInfo')
              wx.removeStorageSync('type')
              wx.removeStorageSync('CoureDatas')
            }
          },
          fail(res) {
            wx.showToast({
              title: '网络异常',
              icon: "none"
            })
            wx.removeStorageSync('token')
            wx.removeStorageSync('userInfo')
            wx.removeStorageSync('type')
            wx.removeStorageSync('CoureDatas')
          }
        })
      }
    })
  }
})