var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    list:[
      {title:"2020-2021学年下学期",value: 20202},
      {title:"2020-2021学年上学期",value: 20201},
      {title:"2019-2020学年下学期",value: 20192},
      {title:"2019-2020学年上学期",value: 20191},
      {title:"2018-2019学年下学期",value: 20182},
      {title:"2018-2019学年上学期",value: 20181},
      {title:"2017-2018学年下学期",value: 20172},
      {title:"2017-2018学年上学期",value: 20171},
      {title:"2016-2017学年下学期",value: 20162},
      {title:"2016-2017学年上学期",value: 20161},
      {title:"2015-2016学年下学期",value: 20152},
      {title:"2015-2016学年上学期",value: 20151},
    ],
    timelist: ["2020-2021学年下学期",
    "2020-2021学年上学期",
    "2019-2020学年下学期",
    "2019-2020学年上学期",
    "2018-2019学年下学期",
    "2018-2019学年上学期",
    "2017-2018学年下学期",
    "2017-2018学年上学期",
    "2016-2017学年下学期",
    "2016-2017学年上学期",
    "2015-2016学年下学期",
    "2015-2016学年上学期"],
    thistime: '请选择学期',
    time: "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  settime(e) {
    console.log(this.data.timelist)
    var that = this;
    this.setData({
      thistime: that.data.list[e.detail.value].title,
      time: that.data.list[e.detail.value].value
    })
  },
  post() {
    var that = this;
    if (that.data.time==""){
      wx.showModal({
        content: '请选择需要查询的学期',
        showCancel: false,
      })
    }
    else{
      wx.navigateTo({
        url: 'table/table?term='+ that.data.time,
      })
    }
  }
})