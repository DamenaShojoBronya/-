var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    thisweek: 1,
    weeklist: [],
    colorArrays: ["#85B8CF", "#90C652", "#D8AA5A", "#FC9F9D", "#0A9A84", "#61BC69", "#12AEF3", "#E29AAD"],
    wlist: [],
    sc: []
  },
  onLoad: function (options) {
    var that = this
    var url = wx.getStorageSync('type') == 1 ? "teacher/courseTable" : "student/courseTable"
    var data = {
      term: options.term,
      token: wx.getStorageSync('token')
    }
    GBH.request(url, data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          sc: res.data.data,
          thisweek: 1,
          thisweek: res.data.data.toweek
        })
        that.getWeekSc(that.data.thisweek)
      }
    })
  },
  getWeekSc(thatweek) {
    var that = this
    var wlist = []
    var weeklist = []
    for (var i in that.data.sc[thatweek]) {
      for (var j in that.data.sc[thatweek][i]) {
        if (that.data.sc[thatweek][i][j].length != 0)
        {
          var kxm = ""
          var kxxx = ""
          for (var k in that.data.sc[thatweek][i][j]) {
            kxm = kxm + "\r\n" +  (that.data.sc[thatweek][i][j][k][0])
            kxxx = kxxx + "\r\n" +  (that.data.sc[thatweek][i][j][k][1])
          }
          var sc = {
            "xqj": j,
            "sksj": i,
            "skcd": 1,
            "kcxx": [kxm, kxxx]
          }
          wlist = wlist.concat(sc)
        }
      }
    }
    var thisWeekHasData
    if(wlist.length == 0)
    {
      thisWeekHasData = false
    }
    else{
      thisWeekHasData = true
    }
    that.setData({
      wlist: wlist,
    })
    for (var i in that.data.sc) {
      if (i != 'toweek')
      {
        weeklist = weeklist.concat("第" + i + "周")
      }    
    }
    that.setData({
      weeklist: weeklist,
      thisweek:thatweek,
      thisWeekHasData:thisWeekHasData
    })
  },
  showCardView(e) {
    var id = e.currentTarget.id
    var that = this
    var string = ""
    console.log(that.data.wlist[id]["kcxx"])
    string = that.data.wlist[id]['kcxx'][1]
    wx.showModal({
      title: string,
      showCancel: false
    })
  },
  changeweek(e) {
    var id = e.detail.value
    id = parseInt(id)
    id += 1
    this.getWeekSc(id)
  }
})