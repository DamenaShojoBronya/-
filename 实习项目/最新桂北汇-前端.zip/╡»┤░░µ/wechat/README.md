# 桂北汇 微信小程序

## 项目简介

> 桂北汇 是由桂林电子科技大学北海校区 网络信息中心 开发的一款校内综合服务应用。


## 项目结构说明

- 本项目使用了 weiui 以及 iView Weapp 框架
- dist 目录为iView Weapp 框架目录
- image目录存放项目所需要的logo、图片等。
- pages目录存放项目各个页面文件。
- utils目录存放公共代码文件
- weiui.wxss 为weiui 框架的样式文件


## 项目页面结构说明
```
course_table 文件夹：课程表功能相关页面
loading 文件夹：加载启动页功能相关页面
index 文件夹：首页页面
my 文件夹：‘我的’页面及其子页面
otherFunction 文件夹：其它功能相关页面（公车路线等）
quit 文件夹：退课功能相关页面
score 文件夹：成绩查询功能相关页面
select 文件夹：选课功能相关页面
selected_option 文件夹：已选课程查询功能相关页面
teacher 文件夹 ：教师端相关页面
xfj 文件夹：学分绩查询功能相关页面
xspj 文件夹：学生评教功能相关页面
```