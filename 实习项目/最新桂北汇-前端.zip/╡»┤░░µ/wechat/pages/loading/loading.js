//login.js
//获取应用实例
var app = getApp();
Page({
  data: {
    modal_display:false
  },
  goToIndex: function (setect) {
    console.log('id', setect.currentTarget.id)
    app.select_type = setect.currentTarget.id
    
    wx.switchTab({
      url: '/pages/index/index',
    });
  },
  
  onLoad: function () {
    var that = this
    setTimeout(function(){
      that.setData({
        modal_display:true
      })
    },5000)
  },

  confirm(){
    this.setData({
      modal_display:false
    })
  }
});