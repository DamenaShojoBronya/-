var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
const TOOLS = require("../../../utils/tools.js");
Page({
  data: {
    ifload:true,
    argv:"",
    xfj:[],
    last_update_time: "暂无",
  },
  onLoad: function (options) {
    var that = this;
    var argv = JSON.parse(options.data)
    var data = {
      term: argv.term,
      stype: argv.stype,
      ch: argv.ch,
    }
    GBH.request("edu/student/selectXfj", data).then(res => {
      if (res == -1) {
        return
      } else {
        var data = {}
        data.姓名 = res.Name
        data.学号 = res.ClassNo
        data.学院 = res.DptName
        data.年级 = res.Grade
        data.学分绩 = res.Xfj
        that.setData({
          xfj: data,
          ifload: false
        })
      }
    })
  },
  onShareAppMessage: function () {
    var that=this;
    return {
      title: "我的学分绩高达" + that.data.xfj.加权平均分+"分，你敢和我比比吗？",
    }
  }
})