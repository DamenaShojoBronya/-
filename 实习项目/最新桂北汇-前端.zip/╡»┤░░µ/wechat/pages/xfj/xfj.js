var app = getApp();
var url = app.globalData.url;
const GBH = require("../../utils/util.js");
const TOOLS = require("../../utils/tools.js");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    coursetype: [{
        name: '按实选课程计算',
        value: 0
      },
      {
        name: '按应选课程计算',
        value: 1,
        checked: true
      }
    ],
    thistime: '请选择学期',
    thistype: "按应选课程计算",
    time: "",
    type: 1,
    isadd: "on",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    GBH.request("common/data/select", {name: "termList"}).then(res => {
      if (res == -1) {
        return
      } else {
        var list = JSON.parse(res);
        that.setData({
          list: list,
          time: list[0].value,
          thistime: list[0].title,
          ifload: false
        })
      }
    })
  },
  settime(e) {
    console.log(this.data.timelist)
    var that = this;
    this.setData({
      thistime: that.data.list[e.detail.value].title,
      time: that.data.list[e.detail.value].value
    })
  },

  settype: function (e) {
    var that = this;
    this.setData({
      type: that.data.coursetype[e.detail.value].value,
      thistype: that.data.coursetype[e.detail.value].name
    })
  },
  switch_check(e) {
    var that = this;
    if (e.detail.value == true) {
      that.setData({
        isadd: "on",
      })
    } else {
      that.setData({
        isadd: ""
      })
    }
  },
  post() {
    if (this.data.time == "") {
      wx.showModal({
        content: '请选择需要查询的学期',
        showCancel: false,
      })
    } else {
      var argv = {
        'term': this.data.time,
        'stype': this.data.type,
        'ch': this.data.isadd == "on" ? 0 : 1,
      }
      console.log(argv)
      wx.navigateTo({
        url: 'table/table?data=' + JSON.stringify(argv),
      })
    }
  }
})