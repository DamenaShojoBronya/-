var app = getApp();
const GBH = require("../../utils/util.js");
var webViewUrl = app.globalData.webViewUrl;

Page({
  data: {
    currentTab: 1,
    tabCont: [],
    newlist: [],
    url: webViewUrl,
    page: 1,
    allPage: 1
  },
  // tab左右滑动切换时
  GetCurrentTab: function (e) {
    var typeid = e.target.dataset.current
    var that = this
    that.setData({
      currentTab: typeid,
      newlist: []
    })
    this.getNews(typeid)
  },
  swithNav: function (e) {
    var typeid = e.target.dataset.current
    var that = this
    that.setData({
      currentTab: typeid,
      newlist: []
    })
    this.getNews(typeid)
  },
  onLoad() {
    var that = this
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    GBH.request("news/item/get", {}).then(res => {
      if (res == -1) {
        wx.navigateBack({
          delta: 1,
        })
        return
      }
      that.setData({
        tabCont: res
      })
      var id = res[0].id
      that.getNews(id)
    })
  },
  onReachBottom: function () {
    var index = this.data.page + 1
    var typeid = this.data.currentTab
    this.getNews(typeid, index)
  },
  bindscrolltolower: function (e) {
    this.onReachBottom();
  },
  getNews: function(id, page=1){
    var that = this
    if(page > this.data.allPage){
      wx.showToast({
        title: '没有更多了',
      })
      return;
    }
    wx.showLoading({
      title: '正在加载中！',
    })
    GBH.request("news/news/getNews",{id: id, page: page}).then(res =>{
      if(res == -1){
        wx.hideLoading({})
        return;
      }
      var list = that.data.newlist
      var list = that.data.newlist
      for (const item in res.news) {
        list.push(res.news[item])
      }
      that.setData({
        newlist: list,
        allPage: res.allPages,
        page: res.thisPages
      })
      wx.hideLoading({})
    })
  },
  toNews(e){
    var id = e.currentTarget.dataset.newsid
    wx.navigateTo({
      url: '/pages/page/page?newsid=' + id,
    })
  }
})