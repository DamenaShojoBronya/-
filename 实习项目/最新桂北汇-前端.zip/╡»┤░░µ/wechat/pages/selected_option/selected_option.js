var app = getApp();
var url = app.globalData.url;
const GBH = require("../../utils/util.js");
const TOOLS = require("../../utils/tools.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    list:[],
    thistime: '',
    time: "",
  },
  onLoad: function(options) {
    var that = this;
    GBH.request("common/data/select", {"name" : "termList"}).then(res=>{
      if(res != -1){
        var list = JSON.parse(res);
        that.setData({
          list: list,
          thistime: list[0].title,
          time: list[0].value,
          ifload: false
        })
      }
    })
  },
  settime(e) {
    console.log(this.data.timelist)
    var that = this;
    that.setData({
      thistime: that.data.list[e.detail.value].title,
      time: that.data.list[e.detail.value].value
    })
  },
  post() {
    var that = this;
    if (that.data.time == "") {
      wx.showModal({
        content: '请选择需要查询的学期',
        showCancel: false,
      })
    } else {
      wx.navigateTo({
        url: 'table/table?term=' + that.data.time,
      })
    }
  }
})