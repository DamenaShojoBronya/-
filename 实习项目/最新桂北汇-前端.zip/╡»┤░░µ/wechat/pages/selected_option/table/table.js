var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
const TOOLS = require("../../../utils/tools.js");

Page({

  /**
   * 页面的初始数据
   */

  // 课程详细显示状态
  data: {
    ifload: true,
    sc: [],
    messageText: '点击课程可以查看更详细的信息~',
    showMessageBox: true,
    course_detail: []
  },

  closeMessageBox() {
    this.setData({
      showMessageBox: false
    })
  },

  showCourseDetail(e) {
    var that = this
    that.setData({
      show_course_detail: true
    })
    var num = e.currentTarget.dataset.num //获取当前点击的课程序号
    that.setData({  //将课程详细信息写到集合
      course_detail:[
        '课程编号: ' + that.data.sc[num].Courseno,
        '课程名称: ' + that.data.sc[num].CName,
        '课程类型: ' + that.data.sc[num].TName,
        '课程状态: ' + that.data.sc[num].Stype,
        '教师姓名: ' + that.data.sc[num].TName1
      ]
    })
  },
  closeCourseDetail() {
    var that = this
    that.setData({
      show_course_detail: false
    })
  },
  onLoad: function(options) {
    var that = this;
    
    GBH.request("edu/student/selected", { 'term': options.term }).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          sc: res,
          ifload: false
        })
      }
    })
  }
})