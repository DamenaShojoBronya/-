var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true, //页面是否加载
    list: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var argv = JSON.parse(options.id)
    var id = argv.Id
    var type = options.type
    var data = {
      'id': id,
    }
    GBH.request("edu/student/select", data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          list: res,
          ifload: false,
          type: type
        })
        if (res.length == 0) {
          that.setData({
            result: true,
            resultdata: ["可选课程为空！"]
          })
        }
      }
    })
  },

  toenter(e) {
    var that = this
    var courseData = JSON.stringify(that.data.list[e.target.id])
    wx.navigateTo({
      url: 'details?id=' + courseData,
    })
  },
  post(e) {
    var that = this
    var courseData = that.data.list[e.target.id]
    var type = this.data.type
    var argv = {
      term: courseData.Term,
      courseId: courseData.Courseid,
      courseNo: courseData.Courseno,
      type: type
    }
    console.log(argv)

    wx.showModal({
      title: '提示',
      content: '确定要提交吗？类型：' + type,
      success(res) {
        if (res.confirm) {
          that.setData({
            ifload: true
          })
          GBH.request("edu/student/selectSave", argv).then(res => {
            if (res == -1) {
              that.setData({
                ifload: false
              })
              return
            } else {
              that.setData({
                ifload: false
              })
              wx.showToast({
                title: '课程选择成功！',
              })
              setTimeout(function () {
                wx.navigateBack({
                  delta: 1,
                })
              }, 2000);
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  }
})