var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true, //页面是否加载
    result: false,
    resultdata: [],
    list: [],
    ifopen: [],
    grade: "",
    type: "",
    spno: "",
    ann_search: false,
    ann_search_num: 0,
    ann_search_text: "",
    show_selected_list: false,
    selected_list: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var argv = JSON.parse(options.data)
    var data = {
      'term': argv.term,
      'grade': argv.grade,
      'spno': argv.zhuanye,
      'stype': argv.xueyuan,
    }
    GBH.request("edu/student/selectPlan", data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          list: res,
          ifload: false,
          type: argv.type
        })
        that.setData({
          "list_backup": that.data.list
        })
      }
    })
  },


  //搜索事件
  onSearch(e) {
    console.log(e)
    var that = this
    var newList = []
    wx.pageScrollTo({
      scrollTop: 0
    })
    if (e.detail != "") {
      for (var i in that.data.list) {
        if (that.data.list[i].Cname.indexOf(e.detail) >= 0) {
          newList.push(that.data.list[i])
        }
      }
      that.setData({
        "list": newList
      })
    } else {
      that.setData({
        "list": that.data.list_backup
      })
    }
    that.setData({
      "ann_search_num": that.data.list.length
    })
    that.setData({
      "ann_search_text": "本次查询到 " + that.data.ann_search_num + " 条数据"
    })
    that.setData({
      "ann_search": true
    })
  },

  toenter(e) {
    var that = this
    var courseData = JSON.stringify(that.data.list[e.target.id])
    wx.navigateTo({
      url: 'details/courseList?id=' + courseData + "&type=" + that.data.type
    })
  }
})