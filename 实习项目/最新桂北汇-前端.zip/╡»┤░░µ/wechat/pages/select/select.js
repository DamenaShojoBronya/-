var app = getApp();
var url = app.globalData.url;
const GBH = require("../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    ifnotcanselect: true,
    grade: "",
    term: "请选择学期",
    list: [],
    xueyuanlist: [], //学院表
    thatxueyuan: "请选择学院", //当前学院
    xueyuancode: "", //当前学院代码
    zhuanyelist: [], //专业表
    thatzhuanye: "请选择专业", //当前专业
    zhuanyecode: "", //当前专业代码
    type: "正常"
  },

  onLoad: function (options) {
    var that = this;
    this.getTerm()
    GBH.request("edu/student/selectCheck", {}).then(res => {
      if (res == -1) {
        that.setData({
          ifnotcanselect: true,
          ifload: false
        })
        return
      } else {
        GBH.request("common/spInfo", {}).then(res => {
          wx.getStorage({
            key: 'userInfo',
            success(userInfo) {
              that.setData({
                xueyuanlist: res.college,
                list: res.major,
                ifload: false,
                ifnotcanselect: false,
                grade: userInfo.data.Grade
              })
            }
          })
        })
      }
    })
  },
  getTerm() {
    var that = this;
    GBH.request("common/data/select", {
      name: "termList"
    }).then(res => {
      if (res != -1) {
        var list = JSON.parse(res)
        that.setData({
          termList: list,
          term: list[0].title,
          termCode: list[0].value
        })
      }
    })
  },
  settime(e) {
    var that = this;
    this.setData({
      term: that.data.termList[e.detail.value].title,
      termCode: that.data.termList[e.detail.value].value
    })
  },
  setxueyuan(e) {
    var that = this;
    this.setData({
      thatxueyuan: that.data.xueyuanlist[e.detail.value].name,
      xueyuancode: that.data.xueyuanlist[e.detail.value].no,
    })
    var dpno = this.data.xueyuanlist[e.detail.value].dpno
    var dplist = []
    for (var i in that.data.list) {
      if (that.data.list[i].dpno == dpno) {
        dplist.push(this.data.list[i])
      }
    }
    this.setData({
      zhuanyelist: dplist
    })
  },
  // 选择专业名函数
  setzhuanye(e) {
    var that = this;
    this.setData({
      thatzhuanye: that.data.zhuanyelist[e.detail.value].name,
      zhuanyecode: that.data.zhuanyelist[e.detail.value].no
    })
  },
  switch_check(e) {
    var that = this;
    var type = e.detail.value ? "正常" : "重修"
    that.setData({
      type: type,
    })
  },
  //提交表单函数 
  formSubmit: function (e) {
    var that = this;
    var grade = that.data.grade
    var type = that.data.type
    var term = that.data.termCode
    var xueyuancode = that.data.xueyuancode
    var zhuanyecode = that.data.zhuanyecode
    if (grade == "" || term == "" || xueyuancode == "" || zhuanyecode == "") {
      wx.showToast({
        title: '以上内容均为必填！',
        icon: "none"
      })
      return;
    }
    // 组装数据
    var argv = {
      'grade': grade,
      'xueyuan': xueyuancode,
      'zhuanye': zhuanyecode,
      'term': term,
      "type": type
    }
    wx.navigateTo({
      url: 'enter/enter?data=' + JSON.stringify(argv)
    })
  }
})