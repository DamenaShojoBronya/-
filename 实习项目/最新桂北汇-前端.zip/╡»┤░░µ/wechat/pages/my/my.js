var app = getApp();
const GBH = require("../../utils/util.js");

Page({

  data: {
    display_modal: false,
    iflogin: wx.getStorageSync('token') != "",
    name: wx.getStorageSync('userInfo') == "" ? "" : wx.getStorageSync('userInfo').Name,
  },
  onShow(e){
    var iflogin = wx.getStorageSync('token') != "";
    var name = wx.getStorageSync('userInfo') == "" ? "" : wx.getStorageSync('userInfo').Name;
    this.setData({
      iflogin: iflogin,
      name: name
    })
  },
  changetype(e) {
    console.log(e.currentTarget.id)
    var id = e.currentTarget.id
    this.setData({
      type: id
    })
  },

  modalClick() {
    var that = this
    that.setData({
      "display_modal": false
    })
    //跳转到登录页面
    wx.navigateTo({
      url: 'login/login',
    })
  },
  toLogin() {
    var that = this
    wx.showLoading({
      title: '正在登录',
    })
    var that = this
  //  wx.login({
  //   success(res) {
  //     if (res.code) {
  //       var temp_code = res.code
  //       console.log(temp_code)
  //     }
  //   }
  //  })
  //  return
    wx.login({
      success(res) {
        if (res.code) {
          var temp_code = res.code
          var data = {
            'code': temp_code
          }
          //获取账号绑定状态
          GBH.request("auth/wechat/login", data).then(res => {
            if (res == -1) {
              wx.navigateTo({
                url: 'login/login',
              })
            } else {
              wx.setStorageSync('token', res.token)
              wx.setStorageSync('userInfo', res.userInfo)
              wx.setStorageSync('type', res.type)
              that.setData({
                iflogin: true,
                name: res.userInfo.Name
              })
              wx.hideLoading({
                success: (res) => {},
              })
            }
          })
        } else {
          console.log('微信登录失败！' + res.errMsg)
        }
      }
    })

  },
  showUnLogin() {
    wx.showModal({
      title: '未登录',
      content: '该功能需要登陆后使用',
      cancelText: "暂不登陆",
      confirmText: "去登录",
      success(res) {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/my/login/login',
          })
        }
      }
    })
  },
  update() {
    const updateManager = wx.getUpdateManager()

    updateManager.onCheckForUpdate(function (res) {
      // 请求完新版本信息的回调
      console.log(res.hasUpdate)
    })

    wx.showModal({
      title: '更新提示',
      content: '新版本已经准备好，是否重启应用？',
      success: function (res) {
        if (res.confirm) {
          // 新的版本已经下载好，调用 applyUpdate 应用新版本并重启
          updateManager.applyUpdate()
        }
      }
    })

  },
  unBinding() {
    var that = this;
    wx.showModal({
      title: '再次确认',
      content: '这将会清空您绑定的教务信息',
      confirmText: "确定",
      cancelText: "取消",
      success: function (res) {
        console.log(res);
        if (res.confirm) {
          wx.showToast({
            icon: 'loading',
            title: '正在解除绑定',
          })
          that.setData({
            iflogin: false,
            name: '',
          })
          wx.login({
            success(res) {
              if (res.code) {
                var temp_code = res.code
                var data = {
                  'code': temp_code
                }
                //获取账号绑定状态
                GBH.request("auth/wechat/delete", data).then(res => {
                  wx.removeStorageSync('token')
                  wx.removeStorageSync('userInfo')
                  wx.removeStorageSync('type')
                  wx.removeStorageSync('name')
                  wx.removeStorageSync('CoureDatas')
                  console.log("正在清空绑定信息")
                })
              }
            }
          })
        }
      }
    })
  }
})