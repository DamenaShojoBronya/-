Page({
  data:{
    question:[
      {
        quest:"小程序是学校官方开发的吗？我们的个人信息安全吗？",
        answer:"桂北汇小程序由北海校区网络信息中心进行开发，对于同学们用户的信息严格保密。",
      },
      {
        quest: "忘记密码了怎么办？",
        answer: "桂北汇只负责对接至教务系统，没有权限修改和找回您的密码，如有疑问可以询问辅导员或教务处解决。",
      },
      {
        quest: "总是显示网络错误？ ",
        answer: "显示网络错误可能是使用了第三方代理，为了同学们的信息安全，我们对不安全的会话进行了拦截。 ",
      },
      {
        quest: "无法打开小程序？",
        answer: "无法打开小程序可能是微信版本过低，请尝试更新或重新安装微信。如能正常打开其他小程序，可以尝试清理微信缓存重试。",
      },
    ]
  },
  quit() {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要退出当前账号吗？',
      confirmText: "确定",
      cancelText: "取消",
      success: function (res) {
        console.log(res);
        if (res.confirm) {
          that.setData({
            iflogin: false,
            name: '',
          })
          wx.clearStorage()
          wx.switchTab({
            url: '/pages/index/index',
          })
        }
      }
    })
  }
})