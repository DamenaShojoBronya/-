// pages/my/change_passwd/change_passwd.js
const GBH = require("../../../utils/util.js");

Page({
  data: {
    changed: false, //是否禁用修改按钮按键
    value1:'',
    value2:'',
    value3:'',
    type:''
  },
  onLoad(){
    var type = wx.getStorageSync("type")
    this.setData({
      type : type
    })
  },
  // 修改密码函数
  change(e) {
    // 判断输入合法性 -> 是否为空、密码与确认密码是否一致、新密码是否与原密码一致、密码复杂度（长度>6）、是否包含敏感字符（ | & ，）
    var old_passwd = e.detail.value.old_passwd
    var new_passwd = e.detail.value.new_passwd
    var reNew_passwd = e.detail.value.reNew_passwd

    if (old_passwd == "" || new_passwd == "" || reNew_passwd == "") {
      wx.showToast({
        title: '以上内容不能为空',
        icon: "none"
      })
    } else if (new_passwd != reNew_passwd) {
      wx.showToast({
        title: '密码与确认密码不符',
        icon: "none"
      })
    } else if (old_passwd == new_passwd) {
      wx.showToast({
        title: '新密码不能与原密码相同',
        icon: 'none'
      })
    } else if (new_passwd.length < 6) {
      wx.showToast({
        title: '密码过于简单，请更换密码',
        icon: "none"
      })
    } else if (new_passwd.indexOf(" ") > 0 || new_passwd.indexOf(",") > 0 || new_passwd.indexOf("&") > 0 || new_passwd.indexOf("|") > 0) {
      wx.showToast({
        title: '密码中包含敏感字符可能会使账号无法登陆，请更换密码',
        icon: "none"
      })
    }
    // 修改密码请求
    else {
      var that = this
      wx.showModal({
        title: '再次确认',
        content: '您的密码将修改为:' + new_passwd,
        showCancel: true,
        cancelText: '我再想想',
        success(res) {
          if (res.confirm) {
            var data = {
              func: 'change_passwd',
              cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
              argv: {
                'old_passwd': old_passwd,
                'new_passwd': new_passwd,
                'reNew_passwd': new_passwd
              },
            }
            GBH.request("gbh/edu", data).then(res => {
              if (res.data.status == 1) {
                wx.showModal({
                  title: '修改失败',
                  content: '您输入的原密码有误，请重新输入',
                  showCancel: false,
                  success(res) {
                    if (res.confirm) {
                      that.setData({ value1: '', value2: '', value3: '' })
                      console.log('测试')
                    }
                  }
                })
              } else if (res.data.status == 2) {
                wx.showModal({
                  title: '修改成功',
                  content: '点击重新登录',
                  showCancel: false,
                  success(res) {
                    if (res.confirm) {
                      wx.clearStorage()
                      wx.reLaunch({
                        url: '../login/login',
                      })
                    }
                  }
                })
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
         
        }
      })
    }
  }
})