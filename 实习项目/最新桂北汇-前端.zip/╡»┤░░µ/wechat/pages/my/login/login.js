var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    identity: ['学生', '教师'],
    select_identity: '学生',
    styleColor:'#00abeb',
    identity_type: app.globalData.select_type,
    iflogin: false,
    name: '',
    login: true,
    typelist: [{
        name: '学生',
        id: 0
      },
      {
        name: "教师",
        id: 1
      }
    ],
  },
  setIdentity(e) {
    var that = this;
    console.log(that.data.identity)
    this.setData({
      select_identity: that.data.identity[e.detail.value],
      identity_type: e.detail.value
    })
  },
  changetype(e) {
    var id = e.currentTarget.id
    this.setData({
      type: id
    })
  },
  onLoad(){
  },

  login(e) {
    wx.showToast({
      icon: 'loading',
      title: '正在绑定',
    })
    var that = this;
    var title = "请输入" + "学号/职工号" + "和密码"
    if (e.detail.value.user == "" || e.detail.value.pass == "") {
      wx.showToast({
        title: title,
        icon: 'none',
        duration: 3000
      })
    } else {
      var user = e.detail.value.user;
      var pass = e.detail.value.pass;
      var identity = e.detail.value.identity;
      identity = identity == "" ? 0 : identity
      wx.login({
        success(res) {
          var temp_code = res.code
          wx.getUserInfo({
            success: function (res) {
              var data = {
                code: temp_code,
                username: user,
                password: pass,
                type:identity
              }
              GBH.request("auth/wechat/bind", data).then(res => {
               if(res == -1) {
                 return
               }else{
                 wx.setStorageSync('token', res.token)
                 var userInfo = res.userInfo
                 wx.setStorageSync('name', userInfo.Name)
                 wx.setStorageSync('userInfo', userInfo)
                 wx.setStorageSync('type', res.type)
                 wx.navigateBack({
                  delta: 1,
                })
               }
              })
            }
          })
        }
      })
    }
  },

  
  quit() {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要退出当前账号吗？',
      confirmText: "确定",
      cancelText: "取消",
      success: function(res) {
        console.log(res);
        if (res.confirm) {
          that.setData({
            iflogin: false,
            name: '',
          })
          wx.clearStorage()
        }
      }
    })
  }
})