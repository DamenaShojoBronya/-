var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({
  data: {
    ifload: true,
    info: [],
    name: ""
  },
  onLoad: function (options) {
    var data = wx.getStorageSync('userInfo');
    var info = new Array();
    for (const key in data) {
        var element = data[key];
        if(key != "Dptno" && key != "Spno"){
          var k = key.replace("Spname","专业").replace("DptName","学院").replace("Name","姓名").replace("Stid","学号").replace("Term","学期").replace("Grade","年级")
          var item = {}
          item["id"] = k;
          item["value"] = element;
          info.push(item) 
        }
    }
    console.log(info)
      this.setData({
        ifload: false,
        info: info,
        name: wx.getStorageSync('userInfo').Name
      })
  },
})