var app =getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
const TOOLS = require("../../../utils/tools.js");
Page({
  data: {
    ifload:true,
    sc:[],
    last_update_time: "暂无",
  },
  onLoad: function (options) {
    var that=this;
    var data = {
      func: "creadit",
      cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
      argv: {}
    }

    GBH.request("edu/student/selectXj", data).then(res => {
      if (res == -1) {
        return
      } else {
        let dataList = res
        let allHdxf = 0  //获得学分
        let allJhxf = 0  //计划学分

        for (let i = 0; i < dataList.length; i++) {
          allHdxf+= Number(dataList[i].hdxf)
          allJhxf+= Number(dataList[i].jhxf)
        }
        that.setData({
          needSum:allJhxf,
          getSum:allHdxf
        })
        that.setData({
          sc: dataList,
          ifload: false
        })
      }
    })
  },
})