var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
var teacher;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    name: "",
    course: "",
    list: [],
    py: "请输入评价", //评语
    ifsumb:"false"//是否已经提交
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    var id = options.id;
    this.setData({
      id:id
    })
    teacher = "";
    var data = {
      func: "xspj",
      cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
      argv: {
        type: 'option'
      }
    }
    GBH.request("gbh/edu", data).then(res => {
      if (res == -1) {
        return
      } else {
        var ifsub = (res.data.data[id][4] == "已提交") ? true : false
        teacher = res.data.data[id][3],
          that.setData({
            name: res.data.data[id][2],
            course: res.data.data[id][1],
            ifsumb: ifsub
          })
        teacher = teacher.replace(/&/g, ",")
        data = {
          func: "xspj",
          cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
          argv: {
            'type': 'enter',
            'urls': teacher,
          }
        }
        GBH.request("gbh/edu", data).then(res => {
          if (res == -1) {
            return
          } else {

            if (res.data.data[1][0][1] != "") {
              that.setData({
                py: res.data.data[1][0][1]
              })
            }
            var lis = res.data.data
            for (var i in lis[0]) {
              lis[0][i][0] = lis[0][i][0].replace("</td>", "")
            }
            that.setData({
              list: res.data.data,
              ifload: false
            })

          }
        })
      }
    })
  },



  formSubmit: function (e) {
    var sc = e.detail.value;
    var bintype = e.detail.target.id;
    var postdata = "";
    // 判断是否有空值
    for (var index in sc) {
      postdata = postdata + " " + sc[index]
      if (sc[index] == "") {
        wx.showToast({
          title: '请完成填写以上所有内容！',
          icon: 'none',
          duration: 2000
        })
        return;
      }
    }
    console.log(sc.py.length)
    postdata = sc.py + postdata.replace(sc.py, "")
    console.log(postdata)
    //是否空评论
    if (sc.py == "请输入评价") {
      wx.showToast({
        title: '请完成填写以上所有内容！',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    //sc.py = sc.py.replace(/ /g,"").replace(/"/g,"<<")
    // console.log(sc.py)

    
    // 提交评价
    if (bintype == "submit") {
      var data = {
        func: "xspj",
        cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
        argv: {
          'type': 'enter_req',
          'teacher_urls': teacher,
          'btn_type': 'lwBtntijiao',
          'py': sc.py,
          'scores': postdata.replace(sc.py, "")
        }
      }
      GBH.request("gbh/edu", data).then(res => {
        if (res == -1) {
          return
        } else {
          wx.showToast({
            title: res.data.data,
            icon: 'success',
            duration: 2000,
            success(res) {
              setTimeout(function () {
                wx.navigateBack({
                  delta: 1
                })
              }, 2000)
            }
          })
        }
      })
    }
    // 保存评价
    else if (bintype == "save") {
      var data = {
        func: "xspj",
        cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
        argv: {
          'type': 'enter_req',
          'teacher_urls': teacher,
          'btn_type': 'lwBtnbc',
          'py': sc.py,
          'scores': postdata.replace(sc.py, "")
        }
      }
      GBH.request("gbh/edu", data).then(res => {
        if (res == -1) {
          return
        } else {
          wx.showToast({
            title: res.data.data,
            icon: 'none',
            duration: 2000,
          })
        }
      })
    }
  }
})