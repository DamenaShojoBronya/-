var app = getApp();
var url = app.globalData.url;
const GBH = require("../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload:true,
    list:[],
  },

  onShow: function (options) {
    var that = this;
    that.setData({
      ifload:true
    })
    var data = {
      func: "xspj",
      cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
      argv: {
        type: 'option',
      }
    }
    GBH.request("gbh/edu", data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          list: res.data.data,
          ifload: false
        })
      }
    })
  },
  toenter(e)
  {
    var that=this;
    var id = e.target.id;
    wx.navigateTo({
      url: 'enter/enter?id=' + id,
    })
  }
})