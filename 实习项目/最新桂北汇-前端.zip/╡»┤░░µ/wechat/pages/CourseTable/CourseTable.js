const GBH = require("../../utils/util.js");
Page({
  data: {
    weeks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
    ColorList: ["#6BC5D2", "#47a86c", "#769FCD", "#F9B8BE", "#F2A379#"],
    days: ["周一", "周二", "周三", "周四", "周五", "周六", "周日"],
    lesson: [{
      // 冬季
      type: "0",
      datas: [{
        lesson: 1,
        time: "08:25"
      }, {
        lesson: 2,
        time: "09:20"
      }, {
        lesson: 3,
        time: "10:25"
      }, {
        lesson: 4,
        time: "11:20"
      }, {
        lesson: 5,
        time: "14:30"
      }, {
        lesson: 6,
        time: "15:25"
      }, {
        lesson: 7,
        time: "16:30"
      }, {
        lesson: 8,
        time: "17:25"
      }, {
        lesson: 9,
        time: "19:30"
      }, {
        lesson: 10,
        time: "20:25"
      }, {
        lesson: 11,
        time: "21:20"
      }]
    }, {
      // 夏季
      type: "1",
      datas: [{
        lesson: 1,
        time: "08:25"
      }, {
        lesson: 2,
        time: "09:20"
      }, {
        lesson: 3,
        time: "10:25"
      }, {
        lesson: 4,
        time: "11:20"
      }, {
        lesson: 5,
        time: "15:00"
      }, {
        lesson: 6,
        time: "15:55"
      }, {
        lesson: 7,
        time: "17:00"
      }, {
        lesson: 8,
        time: "17:55"
      }, {
        lesson: 9,
        time: "19:40"
      }, {
        lesson: 10,
        time: "20:35"
      }, {
        lesson: 11,
        time: "21:30"
      }]
    }],
    thisweekdates: [{
      date: "*"
    }, {
      date: "*"
    }, {
      date: "*"
    }, {
      date: "*"
    }, {
      date: "*"
    }, {
      date: "*"
    }, {
      date: "*"
    }],
    ViewSetting: !1,
    NavBarHeight: wx.getSystemInfoSync().statusBarHeight,
    NextIndex: 0,
    now_week_: 9,
    now_week: 9,
    MessageText: "左右滑动可以切换周次哦~\n课表如果显示不正常,请在左侧点击更新课表",
    ShowMessageBox: "false"
  },
  GetDate(Next) {
    var thisweekdates = this.data.thisweekdates
    var date = new Date();
    var tody = date.getDate();
    console.log("a" + date.getDay)
    var weekIndex = date.getDay() > 0 ? date.getDay() - 1 : 6;
    var week = this.data.days[weekIndex]
    for (var i = weekIndex; i >= 0; i--) {
      var day = new Date();
      day.setTime(day.getTime() - (weekIndex - i) * 24 * 60 * 60 * 1000 + Next * 7 * 24 * 60 * 60 * 1000);
      var s1 = day.getDate();
      thisweekdates[i].date = s1;
    }
    for (var i = weekIndex + 1; i < 7; i++) {
      var day = new Date();
      day.setTime(day.getTime() + (i - weekIndex) * 24 * 60 * 60 * 1000 + Next * 7 * 24 * 60 * 60 * 1000);
      var s1 = day.getDate();
      thisweekdates[i].date = s1;
    }
    this.setData({
      thisweekdates: thisweekdates,
      NextIndex: Next,
      now_week: this.data.now_week_ + Next
    })
    if (Next == 0) {
      this.setData({
        now_day: week
      })
    }
  },
  BackThisWeek() {
    this.GetDate(0)
    this.getWeekSc(this.data.now_week_)
  },
  ViewClass(e) {
    var id = e.currentTarget.id
    var that = this
    var string = ""
    console.log(that.data)
    console.log(that.data.wlist[id])
    string = that.data.wlist[id]['kcxx'][0] + "\n周次:" +that.data.wlist[id]['startWeek'] +"~"+that.data.wlist[id]['endWeek']

    wx.showModal({
      title: string,
      showCancel: false
    })
  },
  CloseMessageBox() {
    this.setData({
      ShowMessageBox: false
    })
  },

  check_coursetable_update() {
    var that = this
    that.UpdateCourseData()

    // 根据上次更新时间来决定是否要更新课表数据
    // var last_update_time = wx.getStorageSync("last_update_coursetable_time") //上次获取更新的时间
    // var to_timestamp = Date.parse(new Date()) / 1000
    // if (!last_update_time) {
    //   //没有获取到上次更新的时间，马上开始更新
    //   that.UpdateCourseData()
    // } else if (last_update_time - to_timestamp > 60 * 60 * 24 * 1) {
    //   // 每天更新一次课表
    //   console.log("正在更新课表")
    //   that.UpdateCourseData()
    // }
  },

  onLaunch() {
    console.log('onLaunch监听小程序初始化');
  },

  onShow() {
    var that = this
    // 当课表没有数据时更新课表
    if (wx.getStorageSync("cookie_key") && !(wx.getStorageSync("CoureDatas"))) {
      this.onLoad()
    }
  },
  // 获取当前周次
  GetThisWeekCount() {
    var that = this
    GBH.request("common/data/select", {
      "name": "trem_start_date"
    }).then(res => {
      if (res == -1) {
        wx.hideLoading()
        that.setData({
          ShowMessageBox: false,
          ViewSetting: false,
        })
        return
      }
      var t1 = new Date(res)
      var t2 = new Date()
      var t = new Date(t2 - t1 + 16 * 3600 * 1000)
      var w = parseInt(t.getTime() / 1000 / 3600 / 24) / 7
      var week = w == parseInt(w) ? parseInt(w) : parseInt(w) + 1
      that.setData({
        now_week: week,
        now_week_: week,
        ViewSetting: false
      })
      that.getWeekSc(that.data.now_week)
      wx.hideLoading()
    })
  },
  onLoad() {
    var that = this
    console.log("触发onload")
    that.GetThisWeekCount()
    this.GetDate(0)
    // 缓存没有课表数据时请求获取数据
    console.log("课表缓存", wx.getStorageSync("CoureDatas"))
    if (!wx.getStorageSync("CoureDatas")) {
      console.log("没有课表缓存数据： " + wx.getStorageInfoSync("CoureDatas") + "获取课表数据……")
      that.check_coursetable_update()
    } else {
      console.log("已有课表数据" + wx.getStorageSync("CoureDatas"))
      wx.getStorage({
        key: 'CoureDatas',
        success(res) {
          that.setData({
            sc: wx.getStorageSync("CoureDatas"),
            MessageText: "若有更新课表需要，可手动点击左上角更新课表~",
            ShowMessageBox: true
          })
          console.log(that.data.sc)
        }
      })
    }

    setTimeout(function () {
      that.CloseMessageBox()
    }, 10000)
  },
  CloseShow(e) {
    let x = e.changedTouches[0].clientX;
    if (x < this.data.touchStart && this.data.touchStart - x > 80) {
      this.setData({
        ViewSetting: false
      })
    }
  },
  OpenSetting: function () {
    if (!wx.getStorageSync("token")) {
      return this.setData({
        MessageText: "课程表需要登录后才能看哦~",
        ShowMessageBox: true
      })
    }
    this.setData({
      ViewSetting: !this.data.ViewSetting
    });
  },
  touchStart(e) {
    this.setData({
      touchStart: e.changedTouches[0].clientX,
    });
  },
  touchEnd(e) {
    if (!wx.getStorageSync("token")) {
      return this.setData({
        MessageText: "课程表需要登录后才能看哦~",
        ShowMessageBox: true
      })
    }
    let x = e.changedTouches[0].clientX;
    if (x > this.data.touchStart && x - this.data.touchStart > 80) {
      if (this.data.now_week - 1 < 1) {
        return wx.showToast({
          title: '不能再往前翻啦~',
          icon: 'none',
        });
      }
      this.getWeekSc(this.data.now_week - 1)
      this.GetDate(this.data.NextIndex - 1)
    } else if (x < this.data.touchStart && this.data.touchStart - x > 80) {
      if (this.data.now_week + 1 > 20) {
        return wx.showToast({
          title: '不能再往前后啦~',
          icon: 'none',
        });
      }
      this.getWeekSc(this.data.now_week + 1)
      this.GetDate(this.data.NextIndex + 1)
    }
  },
  getWeekSc(thatweek) {
    var that = this
    var wlist = []
    var weeklist = []
    for (var i in that.data.sc[thatweek - 1]) {
      var kxm = ""
      var kxxx = ""
      var room = ""
      kxm = kxm + "\r\n" + (that.data.sc[thatweek - 1][i].courseName)
      kxxx = kxxx + "\r\n\r\n" + (that.data.sc[thatweek - 1][i].teacherName)
      room =  room + "\r\n\r\n" + that.data.sc[thatweek - 1][i].room
      var sc = {
        "xqj": that.data.sc[thatweek - 1][i].week,
        "sksj": that.data.sc[thatweek - 1][i].seq,
        "startWeek": that.data.sc[thatweek - 1][i].startWeek,
        "endWeek": that.data.sc[thatweek - 1][i].endWeek,
        "skcd": 1,
        "kcxx": [kxm + kxxx + room, kxxx]
      }
      wlist = wlist.concat(sc)
    }
    that.setData({
      wlist: wlist,
    })
  },
  ShowOrtherTerm() {
    wx.navigateTo({
      url: '/pages/teacher/CoureTable/CoureTable',
    })
  },
  UpdateCourseData() {
    var that = this
    wx.showLoading({
      title: '更新中',
    })
    var data = {
      token: wx.getStorageSync('token')
    }
    GBH.request("common/data/crouseTable", data).then(res => {
      if (res == -1) {
        wx.hideLoading()
        wx.setData({
          ShowMessageBox: false,
          ViewSetting: false,
        })
        return
      }
      that.setData({
        sc: res,
        ViewSetting: false
      })
      that.getWeekSc(that.data.now_week)
      wx.hideLoading()
      wx.showToast({
        title: '更新成功',
      })
      wx.setStorageSync("CoureDatas", res)
      wx.setStorageSync("last_update_coursetable_time", Date.parse(new Date()) / 1000)
    })
    wx.hideLoading()
  }
});