var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../../../utils/util.js");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    courseData : []
  },

  onLoad: function(options) {
    var cou = JSON.parse(options.cou);
    this.setData({
      courseData: cou
    })
  }
})