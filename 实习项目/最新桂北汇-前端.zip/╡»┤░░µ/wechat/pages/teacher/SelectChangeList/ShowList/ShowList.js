var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../../utils/util.js");
Page({
  data: {
    course: [],
    ifload: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var id = options.id
    var data = {
      term: id
    }
    GBH.request("edu/teacher/teachTrans", data).then(res => {
      if (res == -1) {
        wx.navigateBack({
          delta: 1,
        })
        return
      } else {
        if (res.length == 0) {
          that.setData({
            hasdata: false,
            course: res,
            ifload: false
          })
        }
        else {
          that.setData({
            hasdata: true,
            course: res,
            ifload: false
          })
        }
      }
    })
  },
  toenter(e) {
    var id = this.data.course[e.currentTarget.id].CourseNo
    var cou = JSON.stringify(this.data.course[e.currentTarget.id])
    wx.navigateTo({
      url: 'data/data?id=' + id + "&&cou=" + cou,
    })
  }
})