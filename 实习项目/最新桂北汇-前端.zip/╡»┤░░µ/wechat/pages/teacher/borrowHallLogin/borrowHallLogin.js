// pages/borrowHallLogin/borrowHallLogin.js
import {
  getUserInfo,
  request
} from "../../../utils/requestUtils.js"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // url: 'https://gbh.codeyee.com:9028',
    url:'https://bhfw.guet.edu.cn/bgt',
    user: "",
    // 关于token的变量
    postTokenData: {},
    token: null,
    isHaveToken: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.ajaxFlow()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console
  },

  // 封装的请求函数
  async awaitRequst(URL, DATA, METHOD) {
    var res = await request({
      url: URL,
      data: DATA,
      method: METHOD,
      header: {
        'content-type': 'application/json',
        "Authorization": this.data.token
      }
    })
    // console.log("提交表单")
    return res;
  },
  // 获取缓存数据
  async getstorageToken() {
    wx.getStorage({
      key: 'teacher_token',
      success: (result) => {
        // console.log("读取的缓存数据", result)
        this.setData({
          token: result.data,
          isHavaToken: true
        })
      },
    });
  },
  // 获取token并且存入缓存中
  async getToken() {
    var result = await this.awaitRequst(this.data.url + '/api/search/unid', this.data.postTokenData, 'post')
    console.log(result.data.data)
    this.setData({
      token: result.data.data,
      isHaveToken: true
    })
    wx.setStorage({
      key: 'teacher_token',
      data: result.data.data,
    });
    console.log("请求了最新token")
  },
  // 获取用户身份
  async getUser() {
    console.log("正在根据加密信息查询用户数据")
    let userdata = await this.awaitRequst(this.data.url + '/admin/info', null, 'GET');
    // if(userdata.data.data.roles!=1){
    //   let userRoles = userdata.data.data.roles;
    //   wx.setStorage({
    //     key: 'userRoles',
    //     data: userRoles,
    //     success: (result)=>{
    //       console.log(result)
    //     },
    //   });
    // }
    let user = userdata.data.data.roles[0];
    // console.log("用户类型", userdata)

    this.setData({
      user: user
    })

    return this.data.user;

  },
  // 通过临时获取加密信息，然后请求个人信息
  async getCodemesUserinfo() {
    // 获取tempId
    var postTokenData = {}
    wx.login({
      success: res => {
        postTokenData.tempId = res.code
      }
    })

    // 获取加密信息和加密向量
    var result = await getUserInfo()
    postTokenData.encryptedData = result.encryptedData;
    postTokenData.vi = result.iv;
    this.setData({
      postTokenData
    })
  },


  // 将表单的数据整理到一个对象中,并发送请求,提交数据
  async ajaxFlow() {
    wx.showLoading({
      title: "正在加载内容",
      mask: true,
    });

    await this.getCodemesUserinfo();
    await this.getToken()

    //  判断是否缓存有token如果没有则获取获取加密数据,然后请求token
    let num = 0
    while (this.data.token == null) {
      num++
      await this.getCodemesUserinfo();
      await this.getToken()
      await this.getstorageToken();
      if (num == 5) {
        return
      }
    }
    // 判断用户身份跳转到相应页面
    // console.log(开始查询用户类型)
    let user = await this.getUser();
    console.log("用户类型", user)
    // user = "终审单位"
    if (user != "普通用户") {
      wx.showLoading({
        title: '正在为您登陆',
        mask: true,
      });
      console.log("if里面的用户类型", user)
      wx.redirectTo({
        url: '../../teacher/borrowList/borrowList?user=' + user,
      });
      wx.hideLoading();
    }
    // 如果是普通用户不用跳转了
    // else {
    //   console.log(user)
    //   wx.navigateTo({
    //     url: '../../teacher/appointmentHallForm/appointmentHallForm?user=' + user,
    //   });
    // }
    wx.hideLoading();
  },
  handleClick(e) {
    // console.log(e)
    let choose = e.target.id
    switch (choose) {
      case "我要申请":
        if (this.data.user == "普通用户") {
          wx.navigateTo({
            url: '../../teacher/appointmentHallForm/appointmentHallForm?user=' + this.data.user,
          });
        } else {
          wx.showToast({
            title: '非普通用户',
            image: '',
            duration: 1000,
            mask: true,
          });
        }

        break;
      case "申请列表":
        wx.navigateTo({
          url: '../../teacher/borrowList/borrowList?user=' + this.data.user,
        });
        break;
    }
  },
})