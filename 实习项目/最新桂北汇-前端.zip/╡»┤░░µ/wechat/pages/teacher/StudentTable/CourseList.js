var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({
  /**
   * 页面的初始数据
   */
  data: {
    course:[],
    ifload:true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var id = options.id
    var data = {
      'term': options.term,
    }
    GBH.request("edu/teacher/courseTable", data).then(res => {
      if (res == -1) {
        return
      } else {
        var list = []
        for (const i in res) {
          var no = res[i].Courseno
          var b = false
          for (const j in list) {
            if(no == list[j].Courseno){
              b = true
            }
          }
          if(!b){
            list.push(res[i])
          }
        }
        that.setData({
          course: list,
          ifload: false,
          term: options.term
        })
      }
    })
  },
  toenter(e){
    var id = this.data.course[e.currentTarget.id].Courseno
    var term = this.data.term
    wx.navigateTo({
      url: 'StudentList/StudentList?id=' + id + "&term=" + term ,
    })
  }
})