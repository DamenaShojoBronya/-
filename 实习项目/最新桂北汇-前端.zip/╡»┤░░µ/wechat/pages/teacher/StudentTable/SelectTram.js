var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    list:[],
    thistime: '请选择学期',
    time: "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      ifload: true
    })
    GBH.request("common/data/select", {
      "name": "termList"
    }).then(res => {
      if (res == -1) {
        wx.navigateBack({
          delta: 1,
        })
        return;
      }
      var list = JSON.parse(res)
      that.setData({
        list: list,
        thistime: list[0].title,
        time: list[0].value,
        ifload: false
      })
    })
  },
  settime(e) {
    console.log(this.data.timelist)
    var that = this;
    this.setData({
      thistime: that.data.list[e.detail.value].title,
      time: that.data.list[e.detail.value].value
    })
  },
  post() {
    var that = this;
    if (that.data.time == "") {
      wx.showModal({
        content: '请选择需要查询的学期',
        showCancel: false,
      })
    }
    else {
      wx.navigateTo({
        url: 'CourseList?term=' + that.data.time,
      })
    }
  }
})