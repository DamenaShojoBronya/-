var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    student: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var id = options.id
    var term = options.term
    var that = this
    var data = {
      term: term,
      courseno: id,
    }
    GBH.request("edu/teacher/selectStudentList", data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          student: res
        })
      }
    })
  },
  showdet(e) {
    console.log(e)
    var sc = this.data.student[e.currentTarget.id]
    wx.showModal({
      title: sc.Name,
      content: '学号：' + sc.Stid  + "\r\n" + "选课类型：" + sc.Stype + "\r\n" + "年级：" + sc.Grade,
      confirmText: "ok",
      showCancel: false
    })
  }
})