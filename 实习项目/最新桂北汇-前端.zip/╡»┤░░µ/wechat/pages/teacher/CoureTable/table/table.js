var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    thisweek: 1,
    weeklist: [],
    colorArrays: ["#85B8CF", "#90C652", "#D8AA5A", "#FC9F9D", "#0A9A84", "#61BC69", "#12AEF3", "#E29AAD"],
    wlist: [],
    sc: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    var that = this
    var url = wx.getStorageSync('type') == 1 ? "edu/teacher/courseTable" : "edu/student/courseTable"
    var data = {
      term: options.term
    }
    GBH.request(url, data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          sc: res,
          thisweek: 1,
        })
        that.getWeekSc(that.data.thisweek)
        wx.hideLoading({
          success: (res) => {},
        })
      }
    })
  },
  getWeekSc(thatweek) {
    var that = this
    var wlist = []
    var weeklist = []
    var data = that.data.sc
    for (var i in data) {
      if (data[i].length != 0) {
        let item = wlist.findIndex(item => {
          return item.xqj == data[i].Week && item.sksj == data[i].Seq;
        });
        var str = (item == -1 ? "" : wlist[item].kcxx) + data[i].Cname + "," + data[i].Name + (data[i].CroomNo == null? "" :("," + data[i].CroomNo)) + "," +
        (data[i].StartWeek == data[i].EndWeek ? ("第" + data[i].StartWeek + "周") : ("第" + data[i].StartWeek + "周-第" + data[i].EndWeek + "周\r\t"))
        var str1 = (item == -1 ? "" : wlist[item].xxxx) + data[i].Cname + "," + data[i].Name + (data[i].CroomNo == null? "" :("," + data[i].CroomNo)) + "," + 
        (data[i].StartWeek == data[i].EndWeek ? ("第" + data[i].StartWeek + "周") : ("第" + data[i].StartWeek + "周-第" + data[i].EndWeek + "周\r\t"))
        var sc = {
          "xqj": data[i].Week,
          "sksj": data[i].Seq,
          "skcd": 1,
          "kcxx": str,
          "xxxx": str1
        }
        if(item >= 0){
          wlist.splice(item, 1)
        }
        wlist = wlist.concat(sc)
        // console.log(str)
      }
    }
    that.setData({
      wlist: wlist,
    })
    for (var i in that.data.sc) {
      weeklist = weeklist.concat("第" + i + "周")
    }
    that.setData({
      weeklist: weeklist,
      thisweek: thatweek,
    })
  },
  // getWeekSc(thatweek) {
  //   var that = this
  //   var wlist = []
  //   var weeklist = []
  //   for (var i in that.data.sc[thatweek]) {
  //     for (var j in that.data.sc[thatweek][i]) {
  //       for (var k in that.data.sc[thatweek][i][j]) {
  //         // xqj代表星期几上课，sksj是上课时间，skcd上课长度，kcxx课程信息--
  //         var sc = {
  //           "xqj": j,
  //           "sksj": i,
  //           "skcd": 1,
  //           "kcxx": that.data.sc[thatweek][i][j][k]
  //         }
  //         wlist = wlist.concat(sc)
  //       }
  //     }
  //   }
  //   var thisWeekHasData
  //   if(wlist.length == 0)
  //   {
  //     thisWeekHasData = false
  //   }
  //   else{
  //     thisWeekHasData = true
  //   }
  //   that.setData({
  //     wlist: wlist,
  //   })
  //   for (var i in that.data.sc) {
  //     weeklist = weeklist.concat("第" + i + "周")
  //   }
  //   that.setData({
  //     weeklist: weeklist,
  //     thisweek:thatweek,
  //     thisWeekHasData:thisWeekHasData
  //   })
  // },
  showCardView(e) {
    console.log(e.currentTarget.id)
    var id = e.currentTarget.id
    var that = this
    var string = ""
    string = that.data.wlist[id]['xxxx']
    wx.showModal({
      title: string,
      showCancel: false
    })
  },
  changeweek(e) {
    var id = e.detail.value
    id = parseInt(id)
    id += 1
    this.getWeekSc(id)
  }
})