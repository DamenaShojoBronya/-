// pages/boform/boform.js
// pages/borrow/borrow.js
import {
  getUserInfo,
  request
} from "../../../utils/requestUtils.js"

Page({

  /**
   * 页面的初始数据
   */
  data: {
    formData: {
      id: 0,
      approvalId: 0,
      beginTime: 0,
      endTime: 0,
      createTime: 0,
      borrowId: 0,
      approvalLeader: "",
      placeId: 0,
      meetingContent: "",
      numCount: 0,
      meetingReq: "",
      borrower: "",
      telephone: 0,
      remarks: "",
      approvalOpinion: 0,
      borrowOpinion: 0,
      feedback: "",
      processingProgress: 0,
      title: ""
    },

    postApproval: {
      approvalOp: 0,
      feedback: null,
      id: 0
    },

    // url: 'https://gbh.codeyee.com:9028',
    url:'https://bhfw.guet.edu.cn/bgt',
    palceUrl: '/rs/gbhPlace/list',
    approveUrl: null,
    urlObj: {

      borrowUnitapprove: '/rs/gbhBorrowUnit/approval', // 初审
      approvayapprove: '/rs/gbhApprovalUnit/approval' // 终审

    },


    // 审批后隐藏按钮
    hiddenButton: true,
    hiddenMeetingContent: false,

    // 借用单位
    departmentList: ["单击选择借用单位"],
    // 可选的报告厅
    meetingRoom: [],
    // 借用单位部门领导
    borrowUnidLeader: ["请先选择借用单位"],

    // 开始借用的时间文本,用于显示
    beginTimeTextDate: "",
    beginTimeTextTime: "",
    // 结束借用的时间文本,用于显示
    endTimeTextDate: "",
    endTimeTextTime: "",

    // 禁用表单变量
    disabled: true,
    // 显示拒绝原因的弹出层变量
    refuseTextShow: false,


    // 普通用户,初审单位,终审单位,权限管理员,超级管理员
    user: "",

    // 拒绝理由模态框显示隐藏变量
    refusePopup: false,
    // 文本域显示/隐藏变量
    textareaShow: false,
    // 选择时间组件的变量,不记得就去看vant文档
    minDate: new Date().getTime(),
    // maxDate: new Date(2030, 10, 1).getTime(),
    currentDate: new Date().getTime(),
    // // 开始借用的时间模态框相关变量
    // selecBegindtTime: false,
    // // 结束借用的时间模态框相关变量
    // selecEndtTime: false,


    // 关于token的变量
    postTokenData: {},
    token: null,
    isHaveToken: false,



    // 步骤条
    steps: [{
        // text: '步骤一',
        desc: '发出申请',
      },
      {
        // text: '步骤二',
        desc: '初审',
      },
      {
        // text: '步骤三',
        desc: '复审',
      },
      {
        // text: '步骤四',
        desc: '批准借用',
      },
    ]
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 获取到相应的参数id,发送请求获取数据

    let formData = JSON.parse(options.objData)
    console.log(formData)
    // 将表单id存入审核接口需要的数据对象postApproval中
    if (options.user == "场地管理员") {
      this.hiddenButton()

    }
    let postApproval = this.data.postApproval
    postApproval.id = formData.id
    postApproval.beginTime = formData.beginTime
    postApproval.endTime = formData.endTime
    this.setData({
      formData,
      user: options.user,
      postApproval

    })
    this.decideUrl(this.data.user);
    this.ajaxFlow();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.getBeginTimeText();
    this.getEndTimeText();
    // this.onMeetingList();
    console.log(this.data.formData.beginTime)
  },




  // 封装的请求函数
  async awaitRequst(URL, DATA, METHOD) {

    var res = await request({
      // url: this.data.url + '/rs/gbhApply/saveApply',
      url: URL,
      data: DATA,
      method: METHOD,
      header: {
        'content-type': 'application/json',
        "Authorization": this.data.token
      }
    })
    // console.log("提交表单")
    return res;
  },

  async ajaxFlow() {
    await this.getstorageToken();
    // 判断是否缓存有token如果没有则获取
    let num = 0
    while (this.data.token == null) {
      // 获取加密数据
      num++
      await this.getCodemesUserinfo();
      await this.getToken()
      if (num == 5) {
        return
      }
    }
    // 查询所有借用部门信息和单位领导信息
    await this.getBorrowUnitl()
    this.getPlaceHall()
    // await this.getUser();

  },


  // 获取缓存数据token
  async getstorageToken() {
    wx.getStorage({
      key: 'teacher_token',
      success: (result) => {
        // console.log("读取的缓存数据", result)
        this.setData({
          token: result.data,
        })
      },
    });
  },

  // 验证token是否过期,如果过期重新获取
  // 通过临时获取加密信息，然后请求个人信息
  async getCodemesUserinfo() {
    // 获取tempId
    var postTokenData = {}
    wx.login({
      success: res => {
        postTokenData.tempId = res.code
      }
    })

    // 获取加密信息和加密向量
    var result = await getUserInfo()
    postTokenData.encryptedData = result.encryptedData;
    postTokenData.vi = result.iv;
    this.setData({
      postTokenData
    })

  },
  // 获取token并且存入缓存中
  async getToken() {
    var result = await this.awaitRequst(this.data.url + '/api/search/unid', this.data.postTokenData, 'post')
    // console.log(result)
    this.setData({
      token: result.data.data,
      isHaveToken: true
    })
    wx.setStorage({
      key: 'teacher_token',
      data: result.data.data,
    });
    let num = 1;
    if (result.data.data == null) {
      this.getCodemesUserinfo()
      this.getToken()
      // console.log("请求了最新token" + num + "次", result.data.data)
    }

  },

  // 发送请求获取借用单位
  async getBorrowUnitl() {
    var borrowUnit = await this.awaitRequst(this.data.url + '/api/search/BorrowUnit', null, 'GET')
    // console.log("borrowUnit", borrowUnit.data.data)
    var departmentList = []
    for (var i = 0; i < borrowUnit.data.data.length; i++) {
      departmentList[i] = borrowUnit.data.data[i].department
    }
    // 获取借用单位的领导
    let result = await this.awaitRequst(this.data.url + '/api/search/BorrowUnitLeader/' + this.data.formData.borrowId, null, 'GET');
    // console.log("借用单位领导", result)
    let borrowUnidLeader = [];
    for (let index = 0; index < result.data.data.length; index++) {
      borrowUnidLeader[index] = result.data.data[index].leader;
    }

    this.setData({
      departmentList,
      borrowUnidLeader
    })

  },
  // 获取可借用的报告厅场地
  async getPlaceHall() {
    let placeHall = await this.awaitRequst(this.data.url + this.data.palceUrl, null, 'GET')
    let meetingRoom = []
    console.log(placeHall)
    for (let index = 0; index < placeHall.data.data.length; index++) {
      meetingRoom.push(placeHall.data.data[index].name)
    }

    this.setData({
      meetingRoom
    })
    console.log(this.data.meetingRoom)
  },




  // 不用的代码好像可以删掉了
  // isApprove(e) {
  //   console.log(e.currentTarget.dataset.approve)
  //   let approve = e.currentTarget.dataset.approve
  // },


  // 通过身份判断需要使用的url
  async decideUrl(user) {
    let approveUrl; // 审核url
    let urlObj = this.data.urlObj;
    if (user == "普通用户") {
      // console.log("普通用户没有权限审核")
    } else if (user == "初审单位") {
      approveUrl = urlObj.borrowUnitapprove
      this.setData({
        approveUrl
      })
    } else if (user == "终审单位") {
      approveUrl = urlObj.approvayapprove
      this.setData({
        approveUrl
      })

    }
    return approveUrl
  },

  // 显示拒绝理由的模态框
  refuseTextShow() {
    this.setData({
      refuseTextShow: true
    })
  },
  // 关闭拒绝理由的模态框
  refuseTextClose() {
    this.setData({
      refuseTextShow: false
    })
  },


  // 获取开始时间显示的文本
  getBeginTimeText() {
    let timestamp = this.data.formData.beginTime
    var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = date.getDate() + '';
    var h = date.getHours() + '';
    var m = date.getMinutes() + '';
    // var s = date.getSeconds();
    if (h.length == 1) {
      h = '0' + h + ':';

    }
    if (h.length == 2) {
      h = h + ':';
    }
    if (m.length == 1) {
      m = '0' + m;
    }
    // console.log(h, m)

    this.setData({
      beginTimeTextDate: Y + M + D,
      beginTimeTextTime: h + m
    })

  },
  // 获取结束时间显示的文本
  getEndTimeText() {
    let timestamp = this.data.formData.endTime
    var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = date.getDate() + '';
    var h = date.getHours() + '';
    var m = date.getMinutes() + '';
    if (h.length == 1) {
      h = '0' + h + ':';
    }
    if (h.length == 2) {
      h = h + ':';
    }
    if (m.length == 1) {
      m = '0' + m;
    }
    this.setData({
      endTimeTextDate: Y + M + D,
      endTimeTextTime: h + m
    })
  },

  // 拒绝申请模态框
  refuse(e) {
    this.setData({
      refusePopup: true
    })
  },
  // 取消拒绝申请
  cancellRefuse() {
    this.setData({
      refusePopup: false
    })
  },

  // 发送拒绝申请审核请求
  async ConfirmationRefuse() {
    // this.getRefuseData(e);
    let postApproval = this.data.postApproval
    postApproval.approvalOp = 2
    // let formData  =this.data.formData 

    this.setData({
      refusePopup: false,
      postApproval
    })
    // console.log(this.data.approveUrl)
    var status = await this.awaitRequst(this.data.url + this.data.approveUrl, this.data.postApproval, 'post')
    console.log("拒绝申请的返回状态", status)
    console.log("发送的数据", postApproval)

    wx.showToast({
      title: status.data.message,
      icon: 'none',
      image: '',
      duration: 2000,
      mask: true,
    });



    // 如果请求成功
    if (status.data.code == 200) {
      let formData = this.data.formData
      formData.processingProgress = 3
      // 隐藏button按钮
      this.hiddenButton()
      this.setData({
        formData
      })
    }

  },
  // 隐藏button按钮

  // 发送同意申请审核请求
  async approval() {
    let postApproval = this.data.postApproval
    postApproval.feedback = null
    postApproval.approvalOp = 1

    // console.log(this.data.approveUrl)
    var status = await this.awaitRequst(this.data.url + this.data.approveUrl, postApproval, 'post')
    console.log("同意申请的返回状态", status)
    console.log("发送的数据", postApproval)
    wx.showToast({
      title: status.data.message,
      icon: 'none',
      image: '',
      duration: 2000,
      mask: true,
    });

    // 如果请求成功
    if (status.data.code == 200) {
      let formData = this.data.formData
      // // 2是完成状态,如果表单状态小于2才+1,因为终审单位,
      // if (formData.processingProgress < 2) {
      formData.processingProgress = this.data.formData.processingProgress + 1
      // 隐藏button按钮
      this.hiddenButton()
      // }
      this.setData({
        formData
      })
    }



  },

  // 发送请求后隐藏按钮
  hiddenButton() {
    this.setData({
      hiddenButton: false
    })
  },


  // 拒绝理由的文本
  getRefuseData(e) {
    let postApproval = this.data.postApproval
    postApproval.feedback = e.detail.value
    this.setData({
      postApproval
    })
  },
  enterHidden() {
    this.setData({
      hiddenMeetingContent: true
    })
    // console.log(this.data.hiddenMeetingContent)
  },
  leaveHidden() {
    this.setData({
      hiddenMeetingContent: false
    })
    // console.log(this.data.hiddenMeetingContent)
  }

})