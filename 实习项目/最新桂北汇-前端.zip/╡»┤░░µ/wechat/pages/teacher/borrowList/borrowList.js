// pages/borrow/borrow.js
import {
  getUserInfo,
  request
} from "../../../utils/requestUtils.js"
// import "../../utils/requestUtils.js"
import Toast from '../../../dist/vant/toast/toast.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    formData: {
      approvalId: 1, // 审批ID
      approvalLeader: 0, // 审批单位领导
      approvalOpinion: 0, // 审批单位意见
      beginTime: 1601181304478, // 开始借用时间
      borrowId: 0, // 借用单位ID
      borrowOpinion: 0, // 借用单位意见
      borrower: "", // 借用人
      createTime: 0, // 创建时间
      endTime: 1601181304478, // 结束时间戳
      feedback: "", // 不同意反馈
      id: 0, //申请单号
      meetingContent: "", // 会议内容
      meetingReq: "",
      numCount: 0, // 参会人数
      placeId: 0, // 场地ID
      processingProgress: 0, //处理进度，0未处理，1部门初审，2单位复审，3不同意
      remarks: "", // 申请备注
      telephone: "" // 电话
    },

    // 获取的列表数据
    waitFormList: [],
    alreadyFormList: [],
    // 抽离并且转换成的时间文本数据
    waitTimeTextList: [],
    alreadyTimeTextList: [],


    // 显示用户切换的按钮
    switchUserHide: true,


    chooseStatus: [{
        text: '未处理',
        value: 0
      },
      {
        text: '已处理',
        value: 1
      },
    ],
    chooseStatusIndex: 0,

    // 控制监听页面显示的请求,第一次不执行
    onlyFirst: false,

    // url: 'https://gbh.codeyee.com:9028',
    url:'https://bhfw.guet.edu.cn/bgt',
    // url: 'http://192.168.113.220:8080/',

    // 身份标识
    user: "",
    // 身份列表
    userList: "",
    userIndex: 0,
    // userindex: 0,
    // userlenth: 1,

    // 通过身份标识,判断用到的url存入下列变量中

    waitUrl: null,
    alreadyUrl: null,
    approveUrl: null,
    urlObj: {
      // 普通用户
      ordinaryAwaitUrl: '/rs/gbhApply/listApply', // 查询正在申请记录
      ordinaryOldtUrl: '/rs/gbhApply/oldApply', // 查询已结束记录
      // 初审单位
      borrowUnitAwaitUrl: '/rs/gbhBorrowUnit/listApply', //查询待审批表
      borrowUnitOldUrl: '/rs/gbhBorrowUnit/oldApply', //查询已审批表
      borrowUnitapprove: '/rs/gbhBorrowUnit/approval', // 初审
      // 复审单位
      approvalAwaitUrl: '/rs/gbhApprovalUnit/listApply', // 查询待审批表
      approvayOldUrl: '/rs/gbhApprovalUnit/oldApply', //查询已审批表
      approvayapprove: '/rs/gbhApprovalUnit/approval' // 终审


      // '/rs/gbhApprovalUnit/allApply', //分页// 查询待审批表
      // '/rs/gbhApply/list',//分页 // 查询正在申请记录
    },
    //分页组件的当前页码
    pagesCurrent: 1,
    // 未处理状态的总页数
    waitTotalPage: 0,
    // 已处理状态的总页数
    alreadyTotalPage: 0,
    // pageSize 每页的条数
    pageSize: 10,
    // 第几页的变量 pageNum
    pageNum: 1,

    // 关于token的变量
    postTokenData: {},
    token: null,
    // isHaveToken: false,
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 获取传入的用户类型
    // if (options.user != null) {
    //   let user = options.user
    //   this.setData({
    //     user
    //   })
    //   this.decideUrl(this.data.user);
    // } else {
    //   this.getstorageToken();
    //   this.getUser()
    // }
    // if (this.data.user != null) {
    //   this.decideUrl(this.data.user);
    // }
    // else {
    //   this.getUser()
    //   this.decideUrl(this.data.user);
    // }
    // 将数据执行的流程封装到一个函数内
    this.ajaxFlow();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  // 监听页面显示
  onShow: function () {
    // 第一次不执行,因为刚开始没必要在这里执行,而且,此时可能还没token
    if (this.data.onlyFirst) {

      this.getWaitFormList();
      this.getalreadyFormList();
    } else {
      this.setData({
        onlyFirst: true
      })
    }
  },
  // 监听页面下拉
  onPullDownRefresh: function () {
    // let switchUserHide = !(this.data.switchUserHide)
    this.setData({
      switchUserHide: false
    })
    console.log(this.data.switchUserHide)
    this.ajaxDown();
    wx.stopPullDownRefresh()

  },

  async ajaxDown() {


    // 直接下拉切换身份

    // let userindex = this.data.userindex;
    // wx.showLoading({
    //   title: "正在切换身份",
    //   mask: true,
    // });

    // if (userindex == this.data.userlenth - 1) {
    //   userindex = 0;
    //   wx.showToast({
    //     title: "当前权限:" + this.data.userList[userindex],
    //     icon: 'none',
    //     // duration: 000,
    //     mask: true,

    //   });
    // } else {
    //   userindex++;
    //   wx.showToast({
    //     title: "当前权限:" + this.data.userList[userindex],
    //     icon: 'none',
    //     // duration: 000,
    //     mask: true,

    //   });
    // }

    // this.setData({
    //   userindex
    // })
    // wx.hideLoading();

    // wx.stopPullDownRefresh()

  },

  async ajaxFlow() {
    await this.getstorageToken();
    console.log("此时的token", this.data.token)

    let num = 0;
    while (this.data.token == null) {
      num++
      await this.getCodemesUserinfo();
      await this.getToken();
      if (num == 5) {
        return
      }
    }
    await this.getUser()
    await this.decideUrl(this.data.user);
    this.getWaitFormList();
    this.getalreadyFormList();
  },
  // 获取用户身份判断用户身份
  async getUser() {
    let userdata = await this.awaitRequst(this.data.url + '/admin/info', null, 'GET');
    // console.log("开始获取用户数据", userdata)
    let userIndex = this.data.userIndex;
    let user = userdata.data.data.roles[userIndex];
    wx.showToast({
      title: user,
      duration: 1500,
      mask: false,
    });
    let userList = userdata.data.data.roles;
    console.log(userList, user)
    this.setData({
      user,
      userList
    })
    // return this.data.user;
  },

  // 通过临时获取加密信息，然后请求个人信息
  async getCodemesUserinfo() {
    // 获取tempId
    var postTokenData = {}
    wx.login({
      success: res => {
        postTokenData.tempId = res.code
      }
    })
    // 获取加密信息和加密向量
    var result = await getUserInfo()
    postTokenData.encryptedData = result.encryptedData;
    postTokenData.vi = result.iv;
    this.setData({
      postTokenData
    })
    console.log("获取加密信息:   " + (this.data.postTokenData != null))
  },
  // 获取token并且存入缓存中
  async getToken() {
    console.log("开始请求token")
    var result = await this.awaitRequst(this.data.url + '/api/search/unid', this.data.postTokenData, 'post')
    this.setData({
      token: result.data.data,
      isHaveToken: true
    })
    wx.setStorage({
      key: 'teacher_token',
      data: result.data.data,
    });
    // console.log("加密信息和加密变量", this.data.postTokenData)
    // console.log("token返回值", result.data.data)
    console.log("是否存入了token:   " + (this.data.token != null))
  },


  // 封装的请求函数
  async awaitRequst(URL, DATA, METHOD) {
    // console.log("请求时候的Token", this.data.token)
    // console.log(arguments.callee.toString())
    // console.log()
    var res = await request({
      url: URL,
      data: DATA,
      method: METHOD,
      header: {
        'content-type': 'application/json',
        "Authorization": this.data.token
      }
    })
    return res;
  },


  // 通过用户类型,获取不同的url
  async decideUrl(user) {
    let waitUrl;
    let alreadyUrl;
    // let approveUrl; // 审核url
    let urlObj = this.data.urlObj;

    // console.log("data中的变量丢失", this.data.waitUrl, this.data.alreadyUrl)
    // console.log("data中的变量丢失", urlObj)
    if (user == "普通用户") {
      waitUrl = urlObj.ordinaryAwaitUrl; // 查询正在申请记录
      alreadyUrl = urlObj.ordinaryOldtUrl; // 查询已结束记录

      this.setData({
        waitUrl,
        alreadyUrl
      })
    } else if (user == "初审单位") {
      waitUrl = urlObj.borrowUnitAwaitUrl; // 查询正在申请记录
      alreadyUrl = urlObj.borrowUnitOldUrl; // 查询已结束记录
      // approveUrl = urlObj.borrowUnitapprove  // 审核url
      this.setData({
        waitUrl,
        alreadyUrl
      })
    } else if (user == "终审单位") {
      waitUrl = urlObj.approvalAwaitUrl; // 查询正在申请记录
      alreadyUrl = urlObj.approvayOldUrl; // 查询已结束记录
      // approveUrl = urlObj.approvayapprove  // 审核url
      this.setData({
        waitUrl,
        alreadyUrl
      })
    } else if (user == "场地管理员") {
      waitUrl = urlObj.approvalAwaitUrl; // 查询正在申请记录
      alreadyUrl = urlObj.approvayOldUrl; // 查询已结束记录
      // approveUrl = urlObj.approvayapprove  // 审核url
      this.setData({
        waitUrl,
        alreadyUrl
      })
    }
    // console.log("data中的变量丢失", this.data.waitUrl, this.data.alreadyUrl)
  },


  // 获取缓存数据

  async getstorageToken() {
    wx.getStorage({
      key: 'wx.teacher_token',
      success: (result) => {
        this.setData({
          token: result.data,
        })
        // console.log("缓存数据中已经存入token  :" + (this.data.token != null))
      },
    });
  },


  // 获取未处理的申请列表
  async getWaitFormList() {
    console.log(this.data.token)
    let waitFormList = await this.awaitRequst(this.data.url + this.data.waitUrl + '?' + "pageNum=" + this.data.pageNum + '&' + "pageSize=" + this.data.pageSize, null, 'GET')
    console.log(waitFormList)

    let waitTotalPage = waitFormList.data.data.totalPage
    this.setData({
      waitFormList: waitFormList.data.data.list,
      waitTotalPage
    })
    let waitTimeTextList = this.getCreateTimeTextList(this.data.waitFormList)
    this.setData({
      waitTimeTextList
    })
  },
  // 获取已完成处理的申请列表
  async getalreadyFormList() {
    let alreadyFormList = await this.awaitRequst(this.data.url + this.data.alreadyUrl + '?' + "pageNum=" + this.data.pageNum + '&' + "pageSize=" + this.data.pageSize, null, 'GET')
    console.log(alreadyFormList)
    let alreadyTotalPage = alreadyFormList.data.data.totalPage
    // console.log("alreadyFormList", alreadyFormList)
    this.setData({
      alreadyFormList: alreadyFormList.data.data.list,
      alreadyTotalPage
    })
    let alreadyTimeTextList = this.getCreateTimeTextList(this.data.alreadyFormList)
    this.setData({
      alreadyTimeTextList
    })
  },
  // 获取创建表单的时间
  getCreateTimeTextList(FormList) {
    var timeList = []
    var TimeTextList = []
    FormList.forEach(e => {
      let createTime = e.createTime
      timeList.push(createTime)
    });
    for (let index = 0; index < timeList.length; index++) {
      var timeObj = this.getTimeText(timeList[index]);
      TimeTextList[index] = timeObj.TimeTextDate + " " + timeObj.TimeTextTime
    }
    return TimeTextList;
  },


  // 获取筛选需要查询的列表状态
  chooseStatus(e) {
    console.log(e.detail)
    this.setData({
      chooseStatusIndex: e.detail,
      pagesCurrent: 1,
      pageNum: 1
    })

    // 发送请求获取相应状态的列表
    if (e.detail == 0) {
      this.getWaitFormList()
    }
    if (e.detail == 1) {
      this.getalreadyFormList()
    }
  },


  // 未处理列表中,单击携带相应表单数据跳转到相应页面
  waitListNavigatorAndData(e) {
    let index = e.currentTarget.dataset.index
    var objData = this.data.waitFormList[index]
    console.log(objData)
    wx.navigateTo({
      url: '../../teacher/boform/boform?objData=' + JSON.stringify(objData) + "&user=" + this.data.user,
    })
  },
  // 已处理列表中,单击携带相应表单数据跳转到相应页面
  alreadyListNavigatorAndData(e) {
    let index = e.currentTarget.dataset.index
    var objData = this.data.alreadyFormList[index]
    wx.navigateTo({
      url: '../../teacher/boform/boform?objData=' + JSON.stringify(objData) + "&user=" + this.data.user,
    })
  },

  // 上一页下一页,分页
  handleChangePage({
    detail
  }) {
    const type = detail.type;
    if (type === 'next') {
      this.setData({
        pagesCurrent: this.data.pagesCurrent + 1,
        pageNum: this.data.pageNum + 1
      });
      this.getalreadyFormList()
      this.getWaitFormList()
    } else if (type === 'prev') {
      this.setData({
        pagesCurrent: this.data.pagesCurrent - 1,
        pageNum: this.data.pageNum - 1
      });
      this.getalreadyFormList()
      this.getWaitFormList()
    }
  },



  // 将时间戳转换成需要的文本
  getTimeText(timestamp) {
    var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = date.getDate() + '';
    var h = date.getHours() + '';
    var m = date.getMinutes() + '';
    // var s = date.getSeconds();
    if (h.length == 1) {
      h = '0' + h + ':';
    }
    if (h.length == 2) {
      h = h + ':';
    }
    if (m.length == 1) {
      m = '0' + m;
    }
    let TimeTextDate = Y + M + D;
    let TimeTextTime = h + m;
    return {
      TimeTextDate,
      TimeTextTime
    }
  },


  // 切换用户身份
  switchUser(e) {
    let userIndex = e.currentTarget.dataset.user;
    this.setData({
      userIndex,
      switchUserHide: true
    })
    // console.log(userIndex)
    this.onLoad();
  }

})