// pages/borrow/borrow.js
import {
  getUserInfo,
  request
} from "../../../utils/requestUtils.js"
import Toast from '../../../dist/vant/toast/toast.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    postFormData: {
      // 表单数据
      beginTime: null, //开始时间戳
      endTime: null, // 结束时间戳
      borrowId: null, //借用单位ID
      placeId: null, //场地ID
      meetingContent: null, //会议内容
      numCount: null, //会议人数
      meetingReq: null, //会议要求
      borrower: null, //借用人
      telephone: null, //电话

      // 非表单数据
      id: 0, // 编号
      approvalLeader: null, //借用单位审批领导

      approvalId: 0, //审批单位
      createTime: 0, //创建时间戳
      remarks: "", //申请备注
      approvalOpinion: 0, //审批单位意见
      borrowOpinion: 0, //借用单位意见
      feedback: "", //不同意反馈
      processingProgress: 0 //处理进度，0未处理，1部门初审，2单位复审，3已完成
    },


    // 借用人不能自己填
    borrower: '',
    // url: 'https://gbh.codeyee.com:9028',
    url:'https://bhfw.guet.edu.cn/bgt',
    palceUrl: '/rs/gbhPlace/list',

    // 关于token的变量
    postTokenData: {},
    token: null,
    isHaveToken: false,


    /* 需要先从后端获取到已下3个数据 */
    // 借用单位
    departmentList: ["单击选择借用单位"],
    // 可选的报告厅
    meetingRoom: [],
    // 可选的报告厅 的 座位
    meetingSize: [],
    // 可选的报告厅具体数据
    meetingRoomData: [],
    // 借用单位部门领导
    borrowUnidLeader: ["请先选择借用单位"],
    // 普通用户,初审单位,终审单位,权限管理员,超级管理员
    user: "",

    // 拒绝理由模态框显示隐藏变量
    refusePopup: false,
    // 拒绝理由文本数据
    refuseData: "",
    // 文本域显示/隐藏变量
    textareaShow: false,
    // 选择时间组件的变量,不记得就去看vant文档
    minDate: new Date().getTime(),
    // maxDate: new Date(2030, 10, 1).getTime(),
    currentDate: new Date().getTime(),
    // 开始借用的时间模态框相关变量
    selecBegindtTime: false,
    // 结束借用的时间模态框相关变量
    selecEndtTime: false,

    // 开始借用的时间
    beginTime: 0,
    // 开始借用的时间文本,用于显示
    beginTimeTextDate: "",
    beginTimeTextTime: "",
    // 结束借用的时间
    endTime: 0,
    // 结束借用的时间文本,用于显示
    endTimeTextDate: "",
    endTimeTextTime: "",


    // 步骤条激活变量,初始值为-1,即可全部未选中
    stepsActive: -1,
    // 借用单位的索引
    departmentIndex: 0,
    // 选择的报告厅索引
    meetingRoomIndex: 0,
    // 借用单位领导索引
    borrowUnidLeaderIndex: 0,

    // 步骤条
    steps: [{
        // text: '步骤一',
        desc: '发出申请',
      },
      {
        // text: '步骤二',
        desc: '初审',
      },
      {
        // text: '步骤三',
        desc: '复审',
      },
      {
        // text: '步骤四',
        desc: '批准借用',
      },
    ]
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.user != null) {
      console.log(options.user)
      let user = options.user
      this.setData({
        user
      })
    }

    // else {
    //   this.getUser()
    // }

    this.ajaxFlow()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },


  // 封装的请求函数
  async awaitRequst(URL, DATA, METHOD) {
    var res = await request({
      url: URL,
      data: DATA,
      method: METHOD,
      header: {
        'content-type': 'application/json',
        "Authorization": this.data.token
      }
    })
    // console.log("提交表单")
    return res;
  },


  // 控制异步请求的流程
  async ajaxFlow() {
    wx.showLoading({
      title: "正在加载内容",
      mask: true,
    });

    await this.getstorageToken();
    //  判断是否缓存有token如果没有则获取获取加密数据,然后请求token
    let num = 0
    while (this.data.token == null) {
      num++
      await this.getCodemesUserinfo();
      await this.getToken()
      if (num == 5) {
        return
      }
    }
    this.getUser()

    // 判断用户身份跳转到相应页面
    // let user = await this.getUser();
    // if (user != "普通用户") {
    //   console.log(user)
    //   wx.navigateTo({
    //     url: '../../teacher/borrowList/borrowList?user=' + user,
    //   });
    // }


    // 查询所有借用部门信息
    await this.getBorrowUnitl()
    // 获取所有报告厅
    await this.getPlaceHall()
    wx.hideLoading();
  },



  // 获取用户身份判断用户身份
  async getUser() {
    let userdata = await this.awaitRequst(this.data.url + '/admin/info', null, 'GET');
    let borrower = userdata.data.data.username
    console.log("用户名", borrower)
    let user = userdata.data.data.roles[0];
    this.setData({
      user,
      borrower
    })

    return this.data.user;

  },


  //  获取表单数据.提交表单
  async formSubmit(e) {

    // 表单页面获取的页面的数据
    let formData = e.detail.value
    // 要根据formData构造后发送请求的数据
    let postFormData = this.data.postFormData

    formData.beginTime = this.data.beginTime;
    formData.endTime = this.data.endTime;
    formData.borrower = this.data.borrower

    // 数据库中的值是从1开始的,正好js中的0和""是相等的,从1开始更好
    formData.borrowId = formData.borrowId + 1;
    formData.approvalLeader = this.data.borrowUnidLeader[this.data.borrowUnidLeaderIndex];
    formData.placeId = formData.placeId + 1;

    console.log("页面的数据", formData)
    // 判断表单还有什么值没填
    for (let key in formData) {
      if (key == "telephone") {
        if (formData[key].length != 11) {
          // wx.showToast({
          //   title: '电话号码不正确',
          //   icon: 'none',
          //   image: '',
          // });
          Toast.fail('电话号码不正确')
          return
        }


      }
      if (formData[key] == null || formData[key] == "" || formData[key] == 0) {

        // beginTime: null, //开始时间戳
        // endTime: null, // 结束时间戳
        // borrowId: null, //借用单位ID
        // approvalLeader: null, //借用单位审批领导
        // placeId: null, //场地ID
        // meetingContent: null, //会议内容
        // numCount: null, //会议人数
        // meetingReq: null, //会议要求
        // borrower: null, //借用人
        // telephone: null, //电话
        // console.log(typeof (formData[key]) + "-----" + formData[key])

        var project
        switch (key) {
          case "beginTime":
            project = "开始时间"
            break;
          case "endTime":
            project = "结束时间"

            break;
          case "borrowId":
            project = "借用单位"

            break;
            // case "approvalLeader":
            //   project = "单位领导"

            //   break;
          case "placeId":
            project = "借用场地"

            break;
          case "meetingContent":
            project = "会议内容"

            break;
          case "numCount":
            project = "会议人数"

            break;
          case "meetingReq":
            project = "会议要求"

            break;
          case "title":
            project = "字幕文字"

            break;
          case "borrower":
            project = "借用人"

            break;
          case "telephone":
            project = "联系电话"

            break;
        }
        Toast.fail(project + '\n' + '还没填哦!');
        return
      }
    }

    // 将表单的数据存入 要发送请求的数据中
    for (let key in formData) {
      if (formData.hasOwnProperty(key)) {
        postFormData[key] = formData[key];
      }
    }


    console.log("发送请求携带的数据", postFormData)
    this.setData({
      postFormData
    })


    // 提交表单数据
    var status = await this.awaitRequst(this.data.url + '/rs/gbhApply/saveApply', this.data.postFormData, 'post')

    if (status.data.code == 200) {
      wx.showToast({
        title: '成功发送申请',
        icon: 'success',
        success: (result) => {
          wx.navigateTo({
            url: "../../teacher/borrowList/borrowList?user=" + this.data.user,
          });

        },
      });
    } else {
      // if (status.data.message.length == 0) {
      //   Toast.fail('发送失败' + '\n' + '请检查');
      // }
      Toast.fail(status.data.message);
    }
  },

  // 将时间戳转换成需要的文本
  getTimeText(timestamp) {
    var date = new Date(timestamp); //时间戳为10位需*1000，时间戳为13位的话不需乘1000

    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = date.getDate() + '';
    var h = date.getHours() + '';
    var m = date.getMinutes() + '';
    // var s = date.getSeconds();
    if (h.length == 1) {
      h = '0' + h + ':';
    }
    if (h.length == 2) {
      h = h + ':';
    }
    if (m.length == 1) {
      m = '0' + m;
    }
    let TimeTextDate = Y + M + D;
    let TimeTextTime = h + m;
    return {
      TimeTextDate,
      TimeTextTime
    }

  },



  // 获取借用单位,获取默认借用单位领导
  async getBorrowUnitl() {
    var borrowUnit = await this.awaitRequst(this.data.url + '/api/search/BorrowUnit', null, 'GET')
    // console.log("borrowUnit", borrowUnit.data.data)
    var departmentList = []
    for (var i = 0; i < borrowUnit.data.data.length; i++) {
      departmentList[i] = borrowUnit.data.data[i].department
    }

    this.setData({
      departmentList
    })
    wx.setStorage({
      key: 'departmentList',
      data: departmentList
    });

    // 获取默认领导(第一个借用单位的审批领导)
    let leaderList = await this.awaitRequst(this.data.url + '/api/search/BorrowUnitLeader/' + 1, null, 'GET');
    let borrowUnidLeader = [];
    for (let index = 0; index < leaderList.data.data.length; index++) {
      borrowUnidLeader[index] = leaderList.data.data[index].leader;
    }
    this.setData({
      borrowUnidLeader
    })

  },
  // 获取可借用的报告厅场地
  async getPlaceHall() {
    let placeHall = await this.awaitRequst(this.data.url + this.data.palceUrl, null, 'GET')
    let meetingRoom = []
    let meetingSize = []
    let meetingRoomData = []
    console.log(placeHall)
    for (let index = 0; index < placeHall.data.data.length; index++) {
      let mRD = placeHall.data.data[index].name + '(' + placeHall.data.data[index].size + ')'
      meetingRoomData.push(mRD)
      meetingRoom.push(placeHall.data.data[index].name)
      meetingSize.push(placeHall.data.data[index].size)
    }
    this.setData({
      meetingRoom,
      meetingSize,
      meetingRoomData
    })
    console.log(this.data.meetingRoom)
  },


  // 通过临时获取加密信息，然后请求个人信息
  async getCodemesUserinfo() {
    // 获取tempId
    var postTokenData = {}
    wx.login({
      success: res => {
        postTokenData.tempId = res.code
      }
    })

    // 获取加密信息和加密向量
    var result = await getUserInfo()
    postTokenData.encryptedData = result.encryptedData;
    postTokenData.vi = result.iv;
    this.setData({
      postTokenData
    })

  },
  // 获取token并且存入缓存中
  async getToken() {
    var result = await this.awaitRequst(this.data.url + '/api/search/unid', this.data.postTokenData, 'post')
    // console.log("请求了最新token ", result)
    this.setData({
      token: result.data.data,
      isHaveToken: true
    })
    wx.setStorage({
      key: 'teacher_token',
      data: result.data.data,
    });
    console.log("请求了新token")
  },

  // 获取缓存数据
  async getstorageToken() {
    wx.getStorage({
      key: 'teacher_token',
      success: (result) => {
        console.log("读取缓存的token数据")
        this.setData({
          token: result.data,
          isHavaToken: true
        })
      },
    });
  },



  // 选择借用单位 更新借用单位领导
  async bindPickerChange(e) {
    let departmentIndex = Number(e.detail.value);
    this.setData({
      departmentIndex: departmentIndex
    })
    // 借用单位的id是从0开始的
    let id = departmentIndex + 1
    console.log(id)

    // 更新借用单位领导
    let result = await this.awaitRequst(this.data.url + '/api/search/BorrowUnitLeader/' + id, null, 'GET');
    // console.log("借用单位领导", result)
    let borrowUnidLeader = [];
    for (let index = 0; index < result.data.data.length; index++) {
      borrowUnidLeader[index] = result.data.data[index].leader;
    }
    this.setData({
      borrowUnidLeader
    })
    // 缓存单位领导信息
    wx.setStorage({
      key: 'borrowUnidLeader',
      data: borrowUnidLeader
    });
  },
  // 选择报告厅
  onChangeMeeting(e) {
    let meetingRoomIndex = Number(e.detail.value);
    console.log(e.detail)
    this.setData({
      meetingRoomIndex: meetingRoomIndex
    })
  },
  // 借用单位领导
  onChangeLeader(e) {
    let borrowUnidLeaderIndex = Number(e.detail.value);
    console.log(borrowUnidLeaderIndex)
    this.setData({
      borrowUnidLeaderIndex
    })
  },


  // 获取文本域内容
  getMeetingContent(e) {
    // console.log(e.detail.value)
    let postFormData = this.data.postFormData;
    postFormData.meetingContent = e.detail.value
  },


  /* 关于时间选择的函数 */

  // 获取最终选择的开始借用时间
  getBeginTime(e) {
    this.setData({
      beginTime: e.detail,
      selecBegintTime: false,
      selecEndtTime: false
    })
    // 获取开始借用时间文本
    let Time = this.getTimeText(e.detail);
    // 将时间戳存入
    let postFormData = this.data.postFormData
    postFormData.beginTime = e.detail

    this.setData({
      beginTimeTextDate: Time.TimeTextDate,
      beginTimeTextTime: Time.TimeTextTime,
      postFormData
    })
  },
  // 获取最终选择的结束借用时间
  getEndTime(e) {
    this.setData({
      endTime: e.detail,
      selecBegintTime: false,
      selecEndtTime: false
    })

    // 获取结束借用时间文本
    let Time = this.getTimeText(e.detail);
    // 将时间戳存入
    let postFormData = this.data.postFormData
    postFormData.endTime = e.detail
    this.setData({
      endTimeTextDate: Time.TimeTextDate,
      endTimeTextTime: Time.TimeTextTime,
      postFormData
    })
  },

  //显示选择开始时间的模态框
  selecBegintTime() {
    this.setData({
      selecBegintTime: true
    })

  },
  //显示选择结束时间的模态框
  selecEndtTime() {
    this.setData({
      selecEndtTime: true
    })
  },
  // 取消时间选择
  cancelSelect() {
    this.setData({
      selecBegintTime: false,
      selecEndtTime: false
    })
  },
  // 清空数据按钮
  clearMeetingNumber() {
    // 借用单位的索引
    // 选择的报告厅索引
    // 借用单位领导索引
    this.setData({
      departmentIndex: 0,
      meetingRoomIndex: 0,
      borrowUnidLeaderIndex: 0
    })
  }
})