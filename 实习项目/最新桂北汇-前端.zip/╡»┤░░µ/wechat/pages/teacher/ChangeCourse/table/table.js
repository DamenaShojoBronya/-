var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    coure_info: [],
    coure: {
      ttklx: [
        "1 调课—因公参加会议",
        "2 调课—因公出差",
        "3 调课—因公进修学习",
        "4 调课—病假",
        "5 调课—事假",
        "6 调课—设备故障",
        "7 调课—其他原因",
        "8 代课",
        "9 停课",
      ],
      "ttkzc": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
      "tbkzc": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
      "tbkxq": [1, 2, 3, 4, 5, 6, 7],
      "tbkjc": [1, 2, 3, 4, 5],
      "tkxq": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
      "tkjc": [1, 2, 3, 4, 5, 6, 7],
    },
    postData: ["请选择调停课类型", "请选择调课周次", "请选择调补课周次", "请选择调补课星期", "请选择调补课节次"]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var id = options.id
    var cou = JSON.parse(options.cou);
    this.setData({
      coure_info: cou
    })
  },
  settime(e) {
    var that = this
    var id = e.target.id
    var value = e.detail.value
    var postData = that.data.postData
    if (id == 0) {
      postData[id] = that.data.coure.ttklx[value]
    } else if (id == 1) {
      postData[id] = that.data.coure.ttkzc[value]
    } else if (id == 2) {
      postData[id] = that.data.coure.tbkzc[value]
    } else if (id == 3) {
      postData[id] = that.data.coure.tbkxq[value]
    } else if (id == 4) {
      postData[id] = that.data.coure.tbkxq[value]
    }
    that.setData({
      postData: postData
    })
  },
  post(e) {
    var that = this
    var subdata = JSON.stringify(that.data.postData)
    console.log(subdata)
    if (that.data.postData[0].indexOf("请选择") >= 0) {
      wx.showModal({
        title: '提示',
        content: "停调课类型已经停调课时间、补课时间为必填选项！",
        confirmText: "我知道了",
        showCancel: false
      })
    } else {
      var changeTeacher = e.detail.value.changeTeacher
      var reason = e.detail.value.reason
      // var postdata = that.data.coure_info.学期 + " " + that.data.coure_info.课号 + " " + that.data.coure_info.星期 + " " + that.data.coure_info.节次 + " " + that.data.coure_info.上课地点 + " " + that.data.postData[0] + " " + reason + " " + that.data.postData[1] + " " + that.data.postData[2] + " " + that.data.postData[3] + " " + that.data.postData[4] + " " + changeTeacher;

      var data = {
        token: wx.getStorageSync("token"),
        term: that.data.coure_info.Term,
        courseno: that.data.coure_info.Courseno,
        ttkxq: that.data.coure_info.Week,
        ttkjc: that.data.coure_info.Seq,
        ttkjs: that.data.coure_info.CroomNo,
        lx: that.data.postData[0], //类型
        yy: reason, //原因
        ttkzc: that.data.postData[1], //调停课周次 
        tbkzc: that.data.postData[2], //调补课周次
        tbkxq: that.data.postData[3], //调补课星期
        tbkjc: that.data.postData[4], //调补课节次
        // dkjs: changeTeacher,        //代课教师
      }
      GBH.request("edu/teacher/addTrans", data).then(res => {
        if (res == -1) {
          return
        } else {
          if(res[0].success == true){
            wx.showModal({
              title: '成功',
              content: '提交调停课申请成功!',
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                wx.navigateBack({
                  delta: 3
                })
              }
            })
          }else{
            wx.showModal({
              title: '失败',
              content: res[0].msg,
              confirmText: "我知道了",
              showCancel: false,
              success(res) {
                wx.navigateBack({
                  delta: 1
                })
              }
            })
          }
        }
      })
    }
  }
})