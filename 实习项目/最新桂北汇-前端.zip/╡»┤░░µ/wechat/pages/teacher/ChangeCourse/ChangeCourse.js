var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({
  data: {
    course: [],
    ifload: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    var course = []
    var data = {
      token: wx.getStorageSync('token'),
      'term': options.term,
    }
    GBH.request("edu/teacher/courseTable", data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          course: res,
          ifload: false
        })
      }
    })
  },
  toenter(e) {
    var id = this.data.course[e.currentTarget.id].CourseNo
    var cou = JSON.stringify(this.data.course[e.currentTarget.id])
    wx.navigateTo({
      url: 'table/table?id=' + id + "&&cou=" + cou,
    })
  }
})