var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    list: [],
    timelist: [],
    thistime: '请选择学期',
    time: "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var data = {
      name: 'termList'
    }
    GBH.request("common/data/select", data).then(res => {
      if (res == -1) {
        wx.navigateBack({
          delta: 1,
        })
        return
      } else {
        var list = JSON.parse(res)
        that.setData({
          list: list,
          thistime: list[0].title,
          time: list[0].value,
          ifload: false
        })
      }
    })
  },
  settime(e) {
    var that = this
    this.setData({
      thistime: that.data.list[e.detail.value].title,
      time: that.data.list[e.detail.value].value
    })
  },
  post() {
    var that = this;
    wx.navigateTo({
      url: 'CourseList?id=' + that.data.time,
    })
  }
})