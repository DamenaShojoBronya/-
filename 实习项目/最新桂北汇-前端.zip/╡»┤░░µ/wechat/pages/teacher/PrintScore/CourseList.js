var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    course: [],
    data_is_null: false,
    ifload: true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var id = options.id
    var that = this
    var data = {
      'term': id,
    }
    GBH.request("edu/teacher/courseTable", data).then(res => {
      if (res == -1) {
        return
      } else {
        if (res.length == 0) { //判断接收到的数据是否为空
          that.setData({
            data_is_null: true,
          })
        }
        var list = []
        for (const i in res) {
          var no = res[i].Courseno
          var b = false
          for (const j in list) {
            if(no == list[j].Courseno){
              b = true
            }
          }
          if(!b){
            list.push(res[i])
          }
        }
        that.setData({
          course: list,
          ifload: false,
          term: id
        })
      }
    })
  }
})