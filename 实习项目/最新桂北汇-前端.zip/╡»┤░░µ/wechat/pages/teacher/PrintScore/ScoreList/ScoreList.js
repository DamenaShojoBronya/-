var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload:true,
    courseInfo: {
    },
    score: [
    ],
    sc: [
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    var id = options.id
    var term = options.term
    var that = this
    var data = {
      courseno: id,
      term: term
    }
    GBH.request("edu/teacher/selectScore", data).then(res => {
      if (res == -1) {
        wx.navigateBack({
          delta: 1,
        })
        return
      } else {
        that.setData({
          score: res,
          sc: res,
          courseInfo: res,
          ifload: false
        })
      }
    })
  },
  showdet(e) {
    console.log(e)
    var sc = this.data.score[e.currentTarget.id]
    wx.showModal({
      title: sc.Name,
      content: '平时成绩：' + sc.Pscj + "\r\n" + "考试成绩：" + sc.Khcj + "\r\n" + "最终成绩：" + sc.Score,
      confirmText: "ok",
      showCancel: false
    })
  }
})