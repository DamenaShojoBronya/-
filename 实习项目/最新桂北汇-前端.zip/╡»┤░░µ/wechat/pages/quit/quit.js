var app = getApp();
var url = app.globalData.url;
const GBH = require("../../utils/util.js");
Page({
  data: {
    ifload: true, //页面是否加载
    ifnotcanselect: true, //退课是否开放
    list: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getStorage({
      key: 'userInfo',
      success(res) {
        var data = {
          term: res.data.Term
        }
        GBH.request("edu/student/quitPlan", data).then(res => {
          if (res == -1) {
            return
          } else {
            if (res.length == 0) {
              that.setData({
                ifnotcanselect: true,
                ifload: false
              })
            } else {
              that.setData({
                ifnotcanselect: false,
                list: res,
                ifload: false
              })
            }
          }
        })
      }
    })
  },
  post(e) {
    var that = this
    var courseData = that.data.list[e.target.id]
    var argv = {
      term: courseData.Term,
      courseNo: courseData.Courseno,
    }
    wx.showModal({
      title: '提示',
      content: '确定要提交吗？此操作不可逆！',
      success(res) {
        if (res.confirm) {
          that.setData({
            ifload: true
          })
          GBH.request("edu/student/quit", argv).then(res => {
            if (res == -1) {
              return;
            } else {
              wx.showToast({
                title: '退选成功！',
                icon: 'none'
              })
              that.onLoad()
            }
          })
        }
      }
    })
  }
})