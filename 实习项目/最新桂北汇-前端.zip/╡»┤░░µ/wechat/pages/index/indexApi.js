// 实例化APP，获取请求URL
var app = getApp()
var globalUrl = app.globalData.url
const GBH = require("../../utils/util.js");


function getToTerm(){
  var that = this
  if (!wx.getStorageSync("toterm")){
    console.log("无学期数据，正在获取当前学期")
    GBH.request("gbh/toterm","","get").then(res => {
      if (res == -1) {
        return
      } else if (res.data.status == "ok") {
        console.log("设置当前学期")
        wx.setStorageSync("toterm", res.data.toterm)
      }else{
        return
      }
    })
  }else{
    console.log("学期数据已存在")
  }
}

// 将函数暴露以实现开放接口
module.exports = {
  getToTerm: getToTerm,
}