var app = getApp();
const GBH = require("../../utils/util.js");
const {
  $Toast
} = require('../../dist/iview/base/index');

Page({
  data: {
    ifload: true, //页面是否初始加载
    userType: wx.getStorageSync("type"),
    iflogin: wx.getStorageSync('token') != "", //用户是否登陆
    swiperIndex: 0,
    display_unbinding_modal: false,
    hidden_ann_img: true,
    display_ann: false, //公告模态框状态
    notice_display: false,
    notice_text: '',
    ann_spinShow: false,
    ann_show_cancel: false,
    ann_show_btn: false,
    ann_btn_url: '',
    ann_button_ok: true,
    ann_button_cancel: false,
    binding_modal_show: false,
    showMessageBox: false,
    messageText: '↓ 课表移动到了左下角 ↓',
    ann_img_height: '350',
    type: wx.getStorageInfoSync("type"),
    new_func_list: ['就业中心'],
    cardCur: 0,
    displayUpdateAnn: false,
    swiperList: [],
    zhaoxing:true
    
  },
  handleSuccess(msg) {
    $Toast({
      content: msg,
      type: 'success'
    });
  },
  // 轮播图聚焦效果
  cardSwiper(e) {
    if (e.detail.source != '') {
      this.setData({
        cardCur: e.detail.current
      })
    }
  },

  unbidning_modalClick() {
    var that = this
    that.setData({
      "display_unbinding_modal": false
    })
   // 跳转到登录页面
    wx.navigateTo({
      url: '/pages/my/login/login',
    })
  },

  gotozhaoxing(){
    this.setData({
      "zhaoxing": false
    })
    wx.navigateTo({
      url: '/pages/zhaoxing/zhaoxing',
    })
  },
  closezhaoxing(){
    this.setData({
      "zhaoxing": false
    })
  },

  disableUpdateAnn() {
    var that = this
    that.setData({
      'displayUpdateAnn': false
    })
  },

  ann_close() {
    var that = this
    that.setData({
      "display_ann": false
    })
  },
  toBannerView(e) {
    var data = e.currentTarget.dataset.data;
    if (data.type == 1) {
      wx.navigateToMiniProgram({
        appId: data.url,
        path: '',
        envVersion: 'release'
      })
      return;
    } else {
      wx.navigateTo({
        url: "/pages/web/web?url=" + data.url,
      })
      return;
    }
  },
  toview(e) {
    var data = e.currentTarget.dataset.data;
    if ((!this.data.iflogin && data.isUse != 0)) {
      this.showUnLogin();
      return;
    }
    if (data.type == 1) {
      wx.navigateToMiniProgram({
        appId: data.url,
        path: '',
        envVersion: 'release'
      })
      return;
    } else {
      wx.navigateTo({
        url: data.url,
      })
      return;
    }
  },

  showUnLogin() {
    wx.showModal({
      title: '未登录',
      content: '该功能需要登陆后使用',
      cancelText: "暂不登陆",
      confirmText: "去登录",
      success(res) {
        if (res.confirm) {
          wx.switchTab({
            url: '/pages/my/my',
          })
        }
      }
    })
  },

  closeMessageBox() {
    this.setData({
      showMessageBox: false
    })
  },
  onLoad() {
    var that = this;
    that.setData({
      ifload: true,
    })
    this.getBannerList();
    this.getMenuList();
    that.setData({
      ifload: false,
    })
  },
  getMenuList() {
    var that = this
    GBH.request("common/menu/get", {}).then(res => {
      if (res == -1) {
        var data = wx.getStorageSync('muneCache')
        if (data == "") {

        } else {
          that.setData({
            menu: data
          })
        }
      } else {
        wx.setStorageSync('muneCache', res)
        that.setData({
          menu: res
        })
      }
    })
  },
  getBannerList() {
    var that = this
    GBH.request("common/banner/get", {}).then(res => {
      if (res == -1) {
        var data = wx.getStorageSync('bannerCache')
        if (data == "") {

        } else {
          that.setData({
            swiperList: data
          })
        }
      } else {
        wx.setStorageSync('bannerCache', res)
        that.setData({
          swiperList: res
        })
      }
    })
  },

  onShow() {
    var that = this;
    wx.setTabBarBadge({
      index: 0,
      text: 'new'
    })
    var userType = wx.getStorageSync("type");
    var iflogin = wx.getStorageSync('token') != "";
    if (userType == 1) {
      that.setData({
        'notice_display': false,
        'display_ann': false
      })
    }
    this.setData({
      userType: userType,
      iflogin: iflogin
    })
  },

  //下拉刷新
  onPullDownRefresh: function () {
    var that = this
    console.log("已下拉")
    wx.showNavigationBarLoading() //在标题栏中显示加载
    //模拟加载
    that.onLoad()
    wx.hideNavigationBarLoading() //完成停止加载
    wx.stopPullDownRefresh() //停止下拉刷新
    that.setData({
      ifload: false,
    })
  },

  onShareAppMessage: function () {
    return {
      title: "我正在使用桂北汇，快来看看吧！",
    }
  }
})