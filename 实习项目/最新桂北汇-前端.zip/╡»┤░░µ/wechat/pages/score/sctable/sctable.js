var app=getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
const TOOLS = require("../../../utils/tools.js");

Page({
  data: {
    ifload:true,
    last_update_time: "暂无",
    
    argv:"",
    sc:[],
    messageText:'点击课程可以查看更详细的信息~',
    showMessageBox: true,
    show_course_detail: false,
    course_detail: []
  },

  closeMessageBox() {
    this.setData({
      showMessageBox: false
    })
  },
  
  // 显示课程详细
  showCourseDetail(e) {
    var that = this
    that.setData({
      show_course_detail: true
    })
    var num = e.currentTarget.dataset.num //获取当前点击的课程序号

    that.setData({  //将课程详细信息写到集合
      course_detail: [
        '课程编号: ' + that.data.sc[num].Courseno,
        '课程名称: ' + that.data.sc[num].CName,
        '课程学分: ' + that.data.sc[num].Xf,
        '课程类型: ' + that.data.sc[num].KcType,
        '课程成绩: ' + that.data.sc[num].Zpxs,
        '成绩类别: ' + that.data.sc[num].Cjlb,
        '考试类别: ' + that.data.sc[num].Examt,
      ]
    })
  },

  // 关闭课程详细模态框
  closeCourseDetail(){
    var that = this
    that.setData({
      show_course_detail: false
    })
  },
  onLoad: function (options) {
    var that=this;
    that.setData({
      ifload: true
    })
    var data = {
      token: wx.getStorageSync('token'),
      term: options.id,
    }
    GBH.request("edu/student/selectSource", data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          sc: res,
          ifload: false
        })
      }
    })
  },

  onPullDownRefresh: function () {
    var that = this
    console.log("已下拉")
    wx.showNavigationBarLoading() //在标题栏中显示加载
    //模拟加载
    that.onLoad()
    wx.hideNavigationBarLoading() //完成停止加载
    wx.stopPullDownRefresh() //停止下拉刷新
    that.setData({
      ifload: false,
    })
  },
})