var app = getApp();
var url = app.globalData.url;
const GBH = require("../../utils/util.js");
const TOOLS = require("../../utils/tools.js");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    last_update_time: "暂无",
    list: [],
    thistime: '请选择学期',
    thistype: "请选择课程性质",
    time: "",
    type: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      ifload: true
    })
    GBH.request("common/data/select", {
      "name": "termList"
    }).then(res => {
      if (res != -1) {
        var list = JSON.parse(res);
        that.setData({
          list: list,
          ifload: false
        })
      }
    })
  },
  settime(e) {
    var that = this;
    this.setData({
      thistime: that.data.list[e.detail.value].title,
      time: that.data.list[e.detail.value].value
    })
  },
  post() {
    var that = this;
    if (that.data.time == "") {
      wx.showModal({
        content: '请选择需要查询的学期和需要查询的课程性质',
        showCancel: false,
      })
    } else {
      wx.navigateTo({
        url: 'sctable/sctable?id=' + that.data.time,
      })
    }
  },
})