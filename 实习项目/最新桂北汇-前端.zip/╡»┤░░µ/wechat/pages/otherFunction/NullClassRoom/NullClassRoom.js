var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({
  /**
   * 页面的初始数据
   */
  data: {
    thisWeek: "请选择第几周",
    thisDay: "请选择星期几",
    thisRoom: "请选择教学楼",
    thisLesson: "请选择第几节课",
    dataList: ["", "", "",""],
    lessonList: ["第一大节", "第二大节", "第三大节", "第四大节", "第五大节"],
    weekList: [],
    dayList: ["周一", "周二", "周三", "周四", "周五", "周六", "周日"],
    roomList: ["第一教学楼", "第二教学楼", "第三教学楼", "第四教学楼", "第五教学楼", "第六教学楼", "第七教学楼", "第八教学楼", "第九教学楼", "第十教学楼"]
  },
  onLoad(e) {
    var that = this
    var weekList = []
    for (var i = 1; i < 21; i++) {
      weekList = weekList.concat("第" + i + "周")
    }
    this.setData({
      weekList: weekList
    })
    var data = {
      func: "query_room",
      cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
      argv: {
        type: "option",
      }
    }
    GBH.request("gbh/edu", data).then(res => {
      if (res == -1) {
        return
      } else {
        var dataList = that.data.dataList
        dataList[0] = res.data.data.toweek
        dataList[1] = res.data.data.today_num
        var toweek = res.data.data.toweek
        var today_num = res.data.data.today_num
        toweek--
        today_num--
        that.setData({
          thisWeek: that.data.weekList[toweek],
          thisDay: that.data.dayList[today_num],
          dataList: dataList,
          ifload: false
        })
      }
    })
  },

  setDa(e) {
    console.log(e)
    var id = e.target.id
    var data = e.detail.value
    var dataList = this.data.dataList
    console.log("选择了第" + id + "个选项的第" + data + "个选择")
    if (id != 2) {
      if (id == 0) {
        this.setData({
          thisWeek: this.data.weekList[data]
        })

      } else if (id == 1) {
        this.setData({
          thisDay: this.data.dayList[data]
        })
      } else {
        this.setData({
          thisLesson: this.data.lessonList[data]
        })
      }
      data++
      dataList[id] = data
    } else {
      dataList[id] = this.data.roomList[data]
      this.setData({
        thisRoom: this.data.roomList[data]
      })
    }
    this.setData({
      dataList: dataList
    })
  },
  post(e) {
    var that = this
    if (this.data.dataList[0] == "" || this.data.dataList[1] == "" || this.data.dataList[2] == "" || this.data.dataList[3] == "") {
      wx.showModal({
        title: '提示',
        content: '以上内容不能为空',
        showCancel: false
      })
    } else {
      wx.navigateTo({
        url: 'NullClassRoomTable?week=' + that.data.dataList[0] + "&&day=" + that.data.dataList[1] + "&&room=" + that.data.dataList[2] + "&&lesson=" + that.data.dataList[3],
      })
    }
  }
})