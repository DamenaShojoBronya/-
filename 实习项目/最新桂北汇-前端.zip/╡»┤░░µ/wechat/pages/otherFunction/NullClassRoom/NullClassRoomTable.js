var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
Page({
  data: {
    classData: [],
    ifload:true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    console.log(options)
    var week = options.week
    var day = options.day
    var room = options.room
    var lesson = options.lesson
    var data = {
      func: "query_room",
      cookie: wx.getStorageSync("cookie_key") + " " + wx.getStorageSync("cookie"),
      argv: {
        type: 'get_data',
        week_num: week,
        inweek:day,
        jc: lesson,
        building_name:room
      }
    }
    GBH.request("gbh/edu", data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          classData: res.data.data,
          ifload: false
        })
      }
    })

  },
})