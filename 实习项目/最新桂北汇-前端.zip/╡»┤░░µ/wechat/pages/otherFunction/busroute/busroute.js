// pages/otherFunction/busroute/busroute.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    routelist: [{
        start: "桂点校门口",
        end: "北海站",
        bus: "16路公交车",
        price: "2",
        route: [
          "桂电北海学院", "驿马村路口", "市中等职业技术学校", "天宁新城", "北海艺术设计学院", "细垌村", "东峰世纪公寓", "银海区政府", "和兴居委会", "和塘新城", "北海九中", "火车站"
        ]
      },
      {
        start: "桂点校门口",
        end: "南珠汽车站",
        bus: "101路公交车",
        price: "2",
        route: [
          "桂电北海校区", "南珠广场", "农机校", "南珠大道马栏村路口", "昌辉驾校", "南珠汽车站"
        ]
      },
      {
        start: "园博园",
        end: "银滩",
        bus: "102路公交车",
        price: "2",
        route: [
          "园博园", "银滩大道曲湾村", "上海路银滩大道路口", "上海路金海岸大道路口", "上海路三号路口", "四号路老干部学院", "银滩"
        ]
      }
    ],
    current: '北海站',
  },
  handleChange({
    detail
  }) {
    this.setData({
      current: detail.key
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})