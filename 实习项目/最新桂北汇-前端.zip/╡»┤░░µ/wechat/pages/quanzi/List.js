// pages/quanzi/List.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    NavBarHeight: wx.getSystemInfoSync().statusBarHeight,
    StyleColor: "#6BC5D2",
    MenuSize: wx.getMenuButtonBoundingClientRect(),
    news_list: [{
      id: 1,
      content: "昨日新上架《西方音乐史简编》等1本书籍，快去看看有没有自己需要的吧~",
      time: "23小时前",
      uid: "98",
      num_comment:1,
      num_like:2,
      image: ["https://img3.doubanio.com/view/subject/m/public/s1834591.jpg"],
      name:"闲置书籍",
      type:"news_list",
      avatar:"http://img-inwhu.afunapp.com/avatar/20190711190742.jpg",
      image_num:1
    }]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})