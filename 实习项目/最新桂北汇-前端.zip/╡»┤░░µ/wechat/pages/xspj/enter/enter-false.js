var app = getApp();
var url = app.globalData.url;
const GBH = require("../../../utils/util.js");
var teacher;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload: true,
    name: "",
    course: "",
    list: [],
    py: "请输入评价", //评语
    ifsumb:"false"//是否已经提交
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    console.log(options)
    var courseData = JSON.parse(options.id)
    console.log(courseData)
    console.log(courseData.name)

    var ifsub = courseData.chk == 1
    that.setData({
      name: courseData.name,
      course: courseData.cname,
      ifsumb: ifsub,
      term: courseData.term,
      teacherno: courseData.teacherno,
      courseno: courseData.courseno,
      courseid: courseData.courseid,
      lb: courseData.lb,
    })
    var data = {
      "term": courseData.term,
      "teacherno": courseData.teacherno,
      "courseno": courseData.courseno,
      "lb": courseData.lb
    }
    GBH.request("edu/student/selectPjIndex", data).then(res => {
      if (res == -1) {
        return
      } else {
        that.setData({
          list: res
        })
        GBH.request("edu/student/selectPjScore", data).then(res => {
          if (res == -1) {
            return
          } else {
            that.setData({
              py: res.Bz
            })
            that.setData({
              ifload: false
            })
          }
        })
      }
    })
  },

  formSubmit: function (e) {
    var sc = e.detail.value;
    var that = this
    var bintype = e.detail.target.id;
    var score = 0;
    var length = 0;
    for (const key in sc) {
      if(sc[key] == ""){
        wx.showToast({
          title: '请完成填写以上所有内容！',
          icon: 'none',
          duration: 2000
        })
        return;
      }
      score = score + Number(sc[key]);
      length++;
    }
    //是否空评论
    if (sc.py == "请输入评价") {
      wx.showToast({
        title: '请完成填写以上所有内容！',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    wx.showLoading({
      title: '提交中',
    })
    score = score / (length - 1)
    var chk = bintype == "submit" ? 1 : 0
    var data = {
      "term": that.data.term,
      "teacherno": that.data.teacherno,
      "courseno": that.data.courseno,
      "courseid": that.data.courseid,
      "params": sc,
      "lb": that.data.lb,
      "chk": chk
    }
    GBH.request("edu/student/savePjMx", data).then(r => {
      if (r == -1) {
        wx.hideLoading({})
        return
      } else {
        data = {
          "term": that.data.term,
          "teacherno": that.data.teacherno,
          "courseno": that.data.courseno,
          "courseid": that.data.courseid,
          "score": score,
          "bz": sc.py,
          "lb": that.data.lb,
          "chk": chk
        }
        GBH.request("edu/student/savePj", data).then(res => {
          if (res == -1) {
            wx.hideLoading({})
            return
          } else {
            wx.hideLoading({})
            wx.showToast({
              title: "提交成功！",
            })
            setTimeout(function () {
              wx.navigateBack({
                delta: 1
              })
            }, 2000)
          }
        })
      }
    })
  }
})