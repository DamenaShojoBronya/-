var app = getApp();
var url = app.globalData.url;
const GBH = require("../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ifload:true,
    list:[],
  },

  onShow: function (options) {
    var that = this;
    that.setData({
      ifload:true
    })
    GBH.request("common/data/select", {name: "pj_trem"}).then(trem => {
      if (trem == -1) {
        return
      } else {
        GBH.request("edu/student/selectCourseByPj", {term: trem}).then(res => {
          if (res == -1) {
            return
          } else {
            that.setData({
              list: res,
              ifload: false
            })
          }
        })
      }
    })
  },
  toenter(e)
  {
    var that=this;
    var courseData = JSON.stringify(that.data.list[e.target.id])
    wx.navigateTo({
      url: 'enter/enter?id=' + courseData,
    })
  }
})